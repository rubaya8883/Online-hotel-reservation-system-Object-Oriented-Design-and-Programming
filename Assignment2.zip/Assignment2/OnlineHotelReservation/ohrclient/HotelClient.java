package ohrclient;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;
import java.util.Scanner;

import ohrcommon.*;

/**
 * program for hotel client application, here name = "//in-csci-rrpc01:2888/Online_hotel";
 * where client lookup for server.
 * @author Rubaya
 *
 */
public class HotelClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			boolean isExit=false;
			//code for the localhost
			
			//String host = "localhost";//args[0];
			//int port = 2403;//Integer.parseInt(args[1]);
			//code for tesla
			String host = args[0];
			int port = Integer.parseInt(args[1]);
			//front controller object
			HotelFrontController frontController = new HotelFrontController();
			frontController.connectToHotel(host,port);
			
			while (!isExit){
				System.out.println("--------------- Online Hotel Reservation ----------------------- ");
				System.out.println("1.Customer Registration ");
				System.out.println("2.Login");
				System.out.println("3.Exit ");
	
				System.out.println("---------------------------------------------------------------- ");
				System.out.println("Select an option: ");
				Scanner scan0 = new Scanner(System.in);
				Integer operation1 = scan0.nextInt();
				if(operation1.equals(1)){
					frontController.customerRegistrationByCustomer();
				}
				else if (operation1.equals(2)){
	                UserLoginView ulv = new UserLoginView();
	                String userData[] = {"",""};
	                userData = ulv.View();
	                boolean checkAuthentication = false;
	                checkAuthentication = frontController.authenticateUser(userData[0],userData[1]);
				}
				else if (operation1.equals(3)){
					System.out.println("You have logged out/exit.");
					isExit = true;
				}
				else {
					System.out.println("Invalid input.");
				}
			}

		} // try block end
		catch(Exception e){
			System.out.println("Error Occoured in client side: "+e.toString());
			e.printStackTrace();
		}

	}

}
