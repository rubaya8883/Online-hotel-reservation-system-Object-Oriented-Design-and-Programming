/**
 * 
 */
package ohrserver;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

import ohrcommon.*;

/**
 * Implements the remote object. The object must extend from UnicastRemoteObject.
 * The object must implement the associated interface "IOperation"
 * @author Rubaya
 *
 */
public class IOperationImpl extends UnicastRemoteObject implements IOperations {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IOperationImpl() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public HotelUser login(String usrname, String pass) throws RemoteException {
		// TODO Auto-generated method stub
        HotelUserController huc = new HotelUserController();
        HotelUser hus  = huc.getUserFromLogin(usrname, pass);
        
        return hus;
	}

	@Override
	public HotelUser register(String[] data) throws RemoteException {
		// TODO Auto-generated method stub
        HotelUser hus = null;
        return hus;
	}
	

	@Override
	public List<HotelRoom> browseHotelRooms(String[] data) throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateHotelRoom(HotelRoom hr) throws RemoteException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean approveHotelReservation(HotelReservation hr) throws RemoteException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public List<HotelReservation> getAllReservation(HotelUser hu) throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HotelReservation getReservation(int reservationId) throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean placeReservation(HotelReservation hr) throws RemoteException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean modifyReservation(HotelReservation hr) throws RemoteException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean cancelReservation(HotelReservation hr) throws RemoteException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean addAdmin(HotelUser hus, HotelAdmin had) throws RemoteException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean updateAdmin(HotelUser hus, HotelAdmin had) throws RemoteException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean deleteAdmin(HotelUser hus, HotelAdmin had) throws RemoteException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean addCustomer(HotelUser hus, HotelCustomer hcs) throws RemoteException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean updateCustomer(HotelUser hus, HotelCustomer hcs) throws RemoteException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean deleteCustomer(HotelUser us, HotelCustomer cs) throws RemoteException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public HotelUser remRegister(String[] data) throws RemoteException {
		// TODO Auto-generated method stub
        HotelUser hus = null;
        return hus;
	}

}
