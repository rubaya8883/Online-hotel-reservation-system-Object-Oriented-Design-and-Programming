/**
 * 
 */
package ohrcommon;

import java.util.Scanner;

/**
 * demo view of admin registration.
 * @author Rubaya
 *
 */
public class RegisterAdminView {
	public String[] View()
    {
        String[] adminData = new String[7];
        System.out.print("Enter admin's name\n");
        
        Scanner scann = new Scanner(System.in);
        adminData[0] = scann.nextLine();
        System.out.print("Enter admin's username\n");
        adminData[1] = scann.nextLine();
        System.out.print("Enter Password:\n");
        adminData[2] = scann.nextLine();
        adminData[3] = "C";
        System.out.print("Enter zone:\n");
        adminData[4] = scann.nextLine();
        System.out.print("Enter Primary/Secondary (P/S):\n");
        adminData[5] = scann.nextLine();
        System.out.print("Enter Cellphone:\n");
        adminData[6] = scann.nextLine();
        
        return adminData;
    }
}
