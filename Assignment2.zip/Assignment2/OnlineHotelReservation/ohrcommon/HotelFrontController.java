/**
 * 
 */
package ohrcommon;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;

/**
 * The FrontController Class is the initial contact point for handling requests for Admin/Customer
 * view. It checks Authentication.
 * @author Rubaya
 *
 */
public class HotelFrontController 
{
	private HotelDispatcher dispatcher;
	public IOperations op;
	public boolean checkAuthentication;

	public HotelFrontController(){
		dispatcher = new HotelDispatcher();
	   }
	
	public void connectToHotel(String host, int port) throws RemoteException{
		try{
			
			//for local host
			//String name="//"+host+":"+port+"/Online_hotel";
			//Registry registry = LocateRegistry.getRegistry(host,port);
			//op = (IOperations)registry.lookup(name);
			//for tesla
			String name="//"+host+":"+port+"/Online_hotel";
			op = (IOperations)Naming.lookup(name);
			
			System.out.println("Found server object from client");
		}catch(Exception ex){
			System.out.println("Client err :" + ex.getMessage());
			ex.printStackTrace();
		}
		
	}
	public void customerRegistrationByCustomer()
	{
        RegisterCustomerView rcv = new RegisterCustomerView();
        String[] dataForCus = rcv.View();
        HotelUser husForCus = null;
        try {
			husForCus = op.register(dataForCus);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.print("Successfully Registered(NOT SAVED IN DATABASE YET)\n"); 
	}
	public void addAdminByAdmin()
	{
        RegisterAdminView rav = new RegisterAdminView();
        String[] dataAdmin = rav.View();
        HotelUser husa = null;
        //HotelAdmin ha = null;
        try {
			husa = op.register(dataAdmin);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.print("Successfully Registered Admin(NOT SAVED IN DB YET)\n"); 

	}
	public void addCustomerByAdmin()
	{
		RegisterCustomerView rcva = new RegisterCustomerView();
        String[] dataForcusA = rcva.View();
        HotelUser husForcusA = null;
        try {
			husForcusA = op.register(dataForcusA);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.print("Successfully Registered the customer by the admin(NOT SAVED IN DB YET)\n"); 
	}
	public void removeCustomerByAdmin()
	{
	
		System.out.println("Not implemented yet.");
	}
	public void removeAdminByAdmin()
	{
		RemoveAdminView rav = new RemoveAdminView();
		String[] dataForRemvAdmin = rav.View();
        HotelUser husForAdmin = null;
        try {
			husForAdmin = op.remRegister(dataForRemvAdmin);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Successfully remove the Admin by the admin(NOT SAVED IN DB YET)\\n");
	}
	public void updateHotelRoomByAdmin()
	{
		System.out.println("Not implemented yet.");	
	}
	// customer activities--
	public void browseHotelRoomByCutomer()
	{
        HotelRoomBrowserView hrbv = new HotelRoomBrowserView();
        String []dataHrbv = hrbv.View();
        try {
			List<HotelRoom> rooms = op.browseHotelRooms(dataHrbv);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.print("\nRooms are available for booking!!\n");
	}
	
	public void makeRoomReservationByCutomer()
	{
        RoomView rvw = new RoomView();
        int id = rvw.View();
        HotelReservation hr = null;
        try {
			op.placeReservation(hr);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.print("\n You have successfully made a reservation!!\n");
        
	}
	public void cancelRoomReservationByCutomer()
	{
    	HotelUser hus1 = null;
		//HotelReservation hr2 = null;
    	List<HotelReservation> allresev1 = null;
		try {
			allresev1 = op.getAllReservation(hus1);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	HotelReservationView hrv1 = new HotelReservationView();
        int reservationId1 = hrv1.View(allresev1);
        HotelReservation hr3 = null;
		try {
			hr3 = op.getReservation(reservationId1);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
			op.cancelReservation(hr3);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.print("\nReservation is successfully cancelled; You may need to pay\n");
	}
	public void modifyRoomReservationByCutomer()
	{
        HotelUser hus1 = null;
		List<HotelReservation> allresev = null;
		try {
			allresev = op.getAllReservation(hus1);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        HotelReservationView hrv = new HotelReservationView();
        int reservationId = hrv.View(allresev);
        HotelReservation hr1 = null;
		try {
			hr1 = op.getReservation(reservationId);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
			op.modifyReservation(hr1);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        System.out.print("\nReservation is successfully modified!!\n");  
	}
	
	private boolean isAuthenticUser(){
		if (checkAuthentication) {
			return true;
		}
		else {
			
			return false;
		}
	   }
	public boolean authenticateUser(String username, String password) throws RemoteException {
		//System.out.println("check authenticate.");
        HotelUser hus1 = null;
		try {
			hus1 = op.login(username,password);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        if (hus1 == null)
        {
            System.out.print("Login unsuccessful\n");
            checkAuthentication = false;
            return checkAuthentication;
        }
        else
        {
        	checkAuthentication = true;
        	if(hus1.role.equals("A"))
        	{
        		dispatchRequest("ADMIN");
        		//System.out.println("You entered operSelection for admin: " + operSelection);
        		
        	}
        	else {
        		dispatchRequest("CUSTOMER");
        		//System.out.println("You entered operSelection for customer: " + operSelection);

        		}
        	return checkAuthentication;
        }
		
	}
	
	private void trackRequest(String request){
	   System.out.println("Page requested: " + request);
	   }

	public void dispatchRequest(String request)
	{
	   //log each request
	   
	   trackRequest(request);
	      
	   //authenticate the user
	   if(isAuthenticUser()){
		   dispatcher.dispatch(request, (HotelFrontController)this);
		   //return opselection;
	   }
	   //return opselection;	
	}
}
