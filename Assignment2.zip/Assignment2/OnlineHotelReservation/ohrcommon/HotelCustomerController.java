/**
 * 
 */
package ohrcommon;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *  Controller class for hotel Customer
 *  server side controller
 * @author Rubaya
 *
 */
public class HotelCustomerController implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    
	public void addCustomer(HotelCustomer hus)
    {
        System.out.print("Customer added successfully! The actual addition to database is yet to be implemented.\n");
    }
    
    public HotelCustomer getCustomer(int Id)
    {
        HotelCustomer hus = null;
        List<HotelCustomer> AllCustomer = null;
        HotelCustomerController ctrl =new HotelCustomerController();
        try {
            AllCustomer = ctrl.getAllCustomers();
        } catch (IOException ex) {
            Logger.getLogger(HotelCustomerController.class.getName()).log(Level.SEVERE, null, ex);
        }
            //System.out.print(AllCustomer.size());
        for (int i = 0; i< AllCustomer.size();i++)
        {
            if (AllCustomer.get(i).id == Id)
            {
                hus = AllCustomer.get(i);
            }
        }
        return hus;
    }
    
    public List<HotelCustomer> getAllCustomers() throws FileNotFoundException, IOException
    {
        List<HotelCustomer> AllCustomer = new ArrayList<HotelCustomer>();
        try{
        	//for local host
            //String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrCustomer.csv";
          //for tesla
            String userDbPath = System.getProperty("user.dir")+ "/ohrcommon"+"/"+"ohrCustomer.csv";
            
            File file = new File(userDbPath);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line = "";
            String[] tempArr;
            int i = 0;

            while((line = br.readLine()) != null) {
               //System.out.print(line+"\n");
               tempArr = line.split(",");
               if (i == 0)
               {
                   i++;
                   continue;
               }
               else{
                   HotelCustomer us = new HotelCustomer(Integer.parseInt(tempArr[0]),tempArr[1],tempArr[2],tempArr[3]);
                   AllCustomer.add(us);
               }
               i++;
           }
        }
         catch(IOException ioe) {
            ioe.printStackTrace();
         }
        return AllCustomer;
    }
}
