/**
 * 
 */
package ohrcommon;

/**
 * Dispatcher Class for admin or customer home view selection based on login info
 * @author HP
 *
 */
public class HotelDispatcher 
{
	private AdminHomeView adminHomeView;
	private CustomerHomeView customerHomeView;
	//int operationSelection;
	public HotelDispatcher()
	{
		adminHomeView = new AdminHomeView();
		customerHomeView = new CustomerHomeView();
	}
	public void dispatch(String request, HotelFrontController hotelFrontController)
	{
		if(request.equalsIgnoreCase("ADMIN"))
		{
			adminHomeView.showAdminHomeView(hotelFrontController);
			//return operationSelection;
		}
		else
		{
			customerHomeView.showCustomerHomeView(hotelFrontController);
			//return operationSelection;
		}	
	}
}
