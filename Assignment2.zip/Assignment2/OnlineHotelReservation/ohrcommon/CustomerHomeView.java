/**
 * 
 */
package ohrcommon;

import java.util.Scanner;

/**
 * View for customer home page after successful login.
 * @author Rubaya
 *
 */
public class CustomerHomeView {
	public void showCustomerHomeView(HotelFrontController hotelFrontController)
	{	boolean isExit = false;
		Integer operation2 = null;
		while(!isExit)
		{
			System.out.print("Your role is: Customer\n");
	        
			System.out.println("---------------Customer Activities----------------------- ");
			System.out.println("1. Browse Rooms ");
			System.out.println("2. Make a reservation ");
			System.out.println("3. Modify an existing reservation ");
			System.out.println("4. Cancel a reservation ");
			System.out.print("5. Exit\n");
			System.out.println("---------------End Customer Activities----------------------");
			System.out.println("Select an option to continue\n");
	
	        Scanner scan2 = new Scanner(System.in);
	        
	        operation2 = scan2.nextInt();
	        //return operation2;
	        if (operation2.equals(1)){
	        	hotelFrontController.browseHotelRoomByCutomer();
	        }
	        else if (operation2.equals(2)){
	        	hotelFrontController.makeRoomReservationByCutomer();
	        }
	        else if(operation2.equals(3)){
	        	hotelFrontController.modifyRoomReservationByCutomer();
	        }
	        else if(operation2.equals(4)){
	        	hotelFrontController.cancelRoomReservationByCutomer();
	        }
			else if(operation2.equals(5)){
				isExit = true;
			}
			else {
				System.out.println("Invalid input.");
			}
		}
	}
}
