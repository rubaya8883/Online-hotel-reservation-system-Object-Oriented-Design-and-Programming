/**
 * 
 */
package ohrcommon;

/**
 * Hotel HotelRoom object (model object).
 * @author Rubaya
 *
 */
public class HotelRoom implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    public int id;
    public int roomNumber;
    public int quantity;
    public String type;
    public String description;
    public double price;
    public int quality;
    public int beds;



    
    public HotelRoom(int id,int roomNumber,int quantity,int quality,int beds,double price,String description,String type)
    {
        this.id = id;
        this.roomNumber = roomNumber;
        this.quantity = quantity;
        this.quality = quality;
        this.beds = beds;
        this.price = price;
        this.description = description;
        this.type = type;
    }
}
