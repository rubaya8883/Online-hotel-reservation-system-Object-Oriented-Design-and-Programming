/**
 * 
 */
package ohrcommon;

import java.util.Scanner;

/**
 * @author Rubaya
 *
 */
public class RemoveAdminView {
	public String[] View()
	{
        String[] adminRmvData = new String[3];
        System.out.print("Enter admin's name\n");
        
        Scanner scann = new Scanner(System.in);
        adminRmvData[0] = scann.nextLine();
        System.out.print("Enter admin's username\n");
        adminRmvData[1] = scann.nextLine();
        
        System.out.print("Enter Cellphone:\n");
        adminRmvData[2] = scann.nextLine();
		return adminRmvData;
		
	}
}
