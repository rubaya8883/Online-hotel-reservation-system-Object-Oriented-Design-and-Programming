/**
 * 
 */
package ohrcommon;

import java.util.List;
import java.util.Scanner;

/**
 * demo view of room reservation according to order id.
 * @author Rubaya
 *
 */
public class HotelReservationView {
    public int View(List<HotelReservation> allresv)
    {
        String[] reservations = {"Order 1, ID: 1", "Order 2, ID: 2", "Order 3, ID: 3\n"};
        System.out.print("Select your reservation Id to continue\n");
        System.out.print("Order 1, ID: 1 \nOrder 2, ID: 2 \nOrder 3, ID: 3\n");
        Scanner scn = new Scanner(System.in);
        int id = scn.nextInt();
        return id;
    }
}
