/**
 * 
 */
package ohrcommon;

import java.util.Scanner;

/**
 * demo view of browsing room availability according to date range.
 * @author Rubaya
 *
 */
public class HotelRoomBrowserView {
    public String[] View()
    {
        String[] roomBdata = new String[3];
        System.out.print("Enter From date " + "(dd/MM/yyyy):\n");
        Scanner obj = new Scanner(System.in);
        roomBdata[0] = obj.nextLine();
        System.out.print("Enter To date " + "(dd/MM/yyyy):\n");
        roomBdata[1] = obj.nextLine();
        System.out.print("Enter Room Type (suit/single/double):\n");
        roomBdata[2] = obj.nextLine();
        return roomBdata;
    }
}
