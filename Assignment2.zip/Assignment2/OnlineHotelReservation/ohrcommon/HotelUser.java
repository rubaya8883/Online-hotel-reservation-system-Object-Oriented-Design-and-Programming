/**
 * 
 */
package ohrcommon;

/**
 *  HotelUser object (model object).
 * @author Rubaya
 *
 */
public class HotelUser implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    public int id;
    public String name;
    public String role;
    public String username;
    public String password;

    
    public HotelUser(int id,String name,String role,String username,String pass)
    {
        this.id = id;
        this.name = name;
        this.role = role;
        this.password = pass;
        this.username = username;
    }
}
