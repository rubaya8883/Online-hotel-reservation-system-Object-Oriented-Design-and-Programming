The submitted folder contains-
1) A read_me file
2) OnlineHotelReservation folder, which contains the project.
3) A jar file for the OnlineHotelReservation project
4) Inside the OnlineHotelReservation folder, there is a Makefile ( to clean and compile all codes in the package folders)
5) a report file as pdf
Please go through the "Description of the files" point from the report
for better understanding of the coding.

Commands needed to run the OnlineHotelReservation Example-

1.ssh username@tesla.cs.uni.edu

2.create a folder with any name ( for example- "oodp")
command - mkdir oodp

3. To change directory permissions-
chmod +rwx filename to add permissions. ( here filename -oodp )

4. copy the OnlineHotelReservation folder to the tesla machine inside the folder named oodp

5. Change the file permission using the command in step 3. then-
cd oodp/OnlineHotelReservation

6. Clean the class files

make clean

7. Compile all java files-

make

8. You can use the following machines for RMI :
in-csci-rrpc01.cs.uni.edu
in-csci-rrpc02.cs.uni.edu
in-csci-rrpc03.cs.uni.edu
in-csci-rrpc04.cs.uni.edu
in-csci-rrpc05.cs.uni.edu
in-csci-rrpc06.cs.uni.edu

For server running select any machine- (eg. login to in-csci-rrpc01.cs.uni.edu machine)
ssh in-csci-rrpc01.cs.uni.edu

9. cd oodp/OnlineHotelReservation

10. ps eaf | grep rmiregistry

11. Check the port id, which will be given to run, (eg. 2888 ).
if rmiregistry job is running, kill it : kill -9 <pid>

12.rmiregistry 2888 &

13. To run the server-
java ohrserver/HotelServer in-csci-rrpc01 <port-number>
for example-
java ohrserver/HotelServer in-csci-rrpc01 2888

 For running the client-

14. # In a different machine: ( To run the client )
(please open another terminal and run command)
ssh username@tesla.cs.uni.edu
15. login to any machine: for example:
ssh in-csci-rrpc02.cs.uni.edu

16. cd oodp/OnlineHotelReservation
17. java ohrclient/HotelClient in-csci-rrpc01 <port-number>
for example-
java ohrclient/HotelClient in-csci-rrpc01 2888

NOTE:
   It will give option to register as a customer and login (as admin or as customer). 
 username is "rubaya"
 and correct password is "rabab". 
Role will be shown as admin

 For customer username is "leo" and password is "leo123".
Or username: aj , password: aj123


