/**
 * 
 */
package ohrserver;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.Date;
import java.util.List;

import ohrcommon.*;

/**
 * Implements the remote object. The object must extend from UnicastRemoteObject.
 * The object must implement the associated interface "IOperation"
 * @author Rubaya
 *
 */
public class IOperationImpl extends UnicastRemoteObject implements IOperations {

	/**
	 * All methods are calling from HotelFrontController class and calls different 
	 * methods of corrosponding controller classes
	 */
	private static final long serialVersionUID = 1L;

	public IOperationImpl() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}
// for user login info check
	@Override
	public synchronized HotelUser login(String usrname, String pass) throws RemoteException {
		// TODO Auto-generated method stub
        HotelUserController huc = new HotelUserController();
        HotelUser hus  = huc.getUserFromLogin(usrname, pass);
        
        return hus;
	}
// for customer user registration 
	@Override
	public synchronized String registerCustomer(HotelUser hus) throws RemoteException {
		// TODO Auto-generated method stub
        //HotelUser hus = null;
		String msg;
		HotelUserController huc = new HotelUserController();
		msg = huc.addUser(hus);
		if (msg.equals("NOTFOUND"))
		{
			return "File not found";
		}
		else if (msg.equals("INSERTED"))
		{
			return "Successfully Registered customer user in Database";
		}
		else if (msg.contentEquals("NOTINSERTED"))
		{
			return "Registration not successful! Error occured";
		}
		
		return "Customer user Successfully Added";

	}
	
// for getting list of room according to search criteria
	@Override
	public synchronized List<HotelRoom> browseHotelRooms(String searchField,String searchOption) throws RemoteException {
		// TODO Auto-generated method stub
		HotelRoomController hrc = new HotelRoomController();
		List<HotelRoom> AllRoomWithFilter = null;
		AllRoomWithFilter = hrc.getSearchedRoomList(searchField, searchOption);
		return AllRoomWithFilter;
	}
// for updating hotel room according to diffrent criteria. paramether here - roomnum, 
	//what thing to be update (description/price/avaliblity ), which thing is selected as update operation
	@Override
	public synchronized String updateHotelRoom(String roomnum, String toupdate, String selection) throws RemoteException {
		// TODO Auto-generated method stub
		String msg;
		HotelRoomController hrc = new HotelRoomController();
		msg = hrc.updateRoom(roomnum, toupdate, selection);
		if (msg.equals("FILENOTFOUND"))
		{
			return "File not found";
		}
		else if (msg.equals("FOUND"))
		{
			return "Successfully updated room in the Database";
		}
		else if (msg.contentEquals("NOTFOUND"))
		{
			return "No data found in the database to be updated";
		}
		return msg;
		
	}

	@Override
	public synchronized boolean approveHotelReservation(HotelReservation hr) throws RemoteException {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public synchronized List<HotelReservation> getAllReservation(HotelUser hu) throws RemoteException {
		// TODO Auto-generated method stub

		return null;
	}

	@Override
	public synchronized HotelReservation getReservation(int reservationId) throws RemoteException {
		// TODO Auto-generated method stub
		return null;
	}
// for a reservation line creation
	@Override
	public synchronized String placeReservation(Date fromDate, Date toDate, String roomType) throws RemoteException {
		// TODO Auto-generated method stub
		
		String msg;
		HotelReservationController hrc = new HotelReservationController();
		msg = hrc.placeReservationLine(fromDate, toDate, roomType);
		return msg;
	}
// modify a reservation
	@Override
	public synchronized String modifyReservation(Date fromDate, Date toDate, int reservationNum) throws RemoteException {
		// TODO Auto-generated method stub
		String msg;
		HotelReservationController hrc = new HotelReservationController();
		msg = hrc.modifyReservationLine(fromDate, toDate, reservationNum);
		return msg;
	}
// cancel a reservation
	@Override
	public synchronized String cancelReservation(int reservationNum, Date dateToday) throws RemoteException {
		// TODO Auto-generated method stub
		String msg;
		HotelReservationController hrc = new HotelReservationController();
		msg = hrc.cancelReservation(reservationNum, dateToday);
		return msg;
	}
// adding a admin to admin csv
	@Override
	public synchronized String addAdmin(HotelAdmin had) throws RemoteException {
		// TODO Auto-generated method stub
		String msg;
		HotelAdminController hac = new HotelAdminController();
		msg = hac.addHotelAdmin(had);
		if (msg.equals("NOTFOUND"))
		{
			return "File not found";
		}
		else if (msg.equals("INSERTED"))
		{
			return "Successfully Registered Admin in Database";
		}
		else if (msg.contentEquals("NOTINSERTED"))
		{
			return "Registration not successful! Error occured";
		}
		return "Admin Successfully Added";
	}

	@Override
	public synchronized boolean updateAdmin(HotelUser hus, HotelAdmin had) throws RemoteException {
		// TODO Auto-generated method stub
		return true;
	}
// delete an admin info
	@Override
	public synchronized String deleteAdmin(String name, String username, String cellphone) throws RemoteException {
		// TODO Auto-generated method stub
		String msg = null;
		HotelAdminController hac = new HotelAdminController();
		msg = hac.deleteHotelAdmin(name, cellphone);
		if (msg.equals("FILENOTFOUND"))
		{
			return "File not found";
		}
		else if (msg.equals("FOUND"))
		{
			return "Successfully deleted Admin from the Database";
		}
		else if (msg.contentEquals("NOTFOUND"))
		{
			return "No data found in the database";
		}
		return msg;
	}
// adding a customer to customer csv
	@Override
	public synchronized String addCustomer(HotelCustomer hcs) throws RemoteException {
		// TODO Auto-generated method stub
		String msg;
		HotelCustomerController hcc = new HotelCustomerController();
		msg = hcc.addCustomer(hcs);
		if (msg.equals("NOTFOUND"))
		{
			return "File not found";
		}
		else if (msg.equals("INSERTED"))
		{
			return "Successfully Registered Customer in Database";
		}
		else if (msg.contentEquals("NOTINSERTED"))
		{
			return "Registration not successful! Error occured";
		}
		return "Customer Successfully Added";
		
	}

	@Override
	public synchronized boolean updateCustomer(HotelUser hus, HotelCustomer hcs) throws RemoteException {
		// TODO Auto-generated method stub
		return true;
	}
// delete a customer from csv
	@Override
	public synchronized String deleteCustomer(String name, String username, String cellphone) throws RemoteException {
		// TODO Auto-generated method stub
		String msg = null;
		HotelCustomerController hcc = new HotelCustomerController();
		msg = hcc.deleteHotelCustomer(name, cellphone);
		if (msg.equals("FILENOTFOUND"))
		{
			return "File not found";
		}
		else if (msg.equals("FOUND"))
		{
			return "Successfully deleted Customer from the Database";
		}
		else if (msg.contentEquals("NOTFOUND"))
		{
			return "No data found in the database";
		}
		return msg;
	}
/*
	@Override
	public HotelUser remRegister(String[] data) throws RemoteException {
		// TODO Auto-generated method stub
        HotelUser hus = null;
        return hus;
	} */
// register an admin user
	@Override
	public synchronized String registerAdmin(HotelUser hus) throws RemoteException {
		// TODO Auto-generated method stub
		String msg;
		HotelUserController huc = new HotelUserController();
		msg = huc.addUser(hus);
		if (msg.equals("NOTFOUND"))
		{
			return "File not found";
		}
		else if (msg.equals("INSERTED"))
		{
			return "Successfully Registered admin user in Database";
		}
		else if (msg.contentEquals("NOTINSERTED"))
		{
			return "Registration not successful! Error occured";
		}
		
		return "Admin user Successfully Added";
	}
// delete an customer user
	@Override
	public synchronized String deleteCustomerUser(String name, String username) throws RemoteException {
		// TODO Auto-generated method stub
		String msg = null;
		HotelUserController huc = new HotelUserController();
		msg = huc.deleteHotelUser(name, username);
		if (msg.equals("FILENOTFOUND"))
		{
			return "File not found";
		}
		else if (msg.equals("FOUND"))
		{
			return "Successfully deleted customer user from the Database";
		}
		else if (msg.contentEquals("NOTFOUND"))
		{
			return "No data found in the database";
		}
		return msg;
	}

	
// delete an admin user
	@Override
	public synchronized String deleteAdminUser(String name, String username) throws RemoteException {
		// TODO Auto-generated method stub
		String msg = null;
		HotelUserController huc = new HotelUserController();
		msg = huc.deleteHotelUser(name, username);
		if (msg.equals("FILENOTFOUND"))
		{
			return "File not found";
		}
		else if (msg.equals("FOUND"))
		{
			return "Successfully deleted admin user from the Database";
		}
		else if (msg.contentEquals("NOTFOUND"))
		{
			return "No data found in the database";
		}
		return msg;
	}


}
