/**
 * 
 */
package ohrcommon;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Rubaya
 * Class for Admin data base implements base template class 
 *
 */
public class UserDB extends CsvConnectionTemplate{
	//for localhost
	//private static final String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrUser.csv";
    //for tesla
  	private static final String userDbPath = System.getProperty("user.dir")+ "/ohrcommon"+"/"+"ohrUser.csv";
	private static final String CSV_HEADER = "id,name,role,username,password";

	
	@Override
	public int getLineNumber() {
		// TODO Auto-generated method stub
        int lines = 0;
        
        try {
 
           // File file = new File("file.txt");
        	//String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrUser.csv";
            LineNumberReader lineNumberReader = new LineNumberReader(new FileReader(userDbPath));
            lineNumberReader.skip(Long.MAX_VALUE);
            lines = lineNumberReader.getLineNumber() - 1;
            lineNumberReader.close();
            
 
        } catch (FileNotFoundException e) {
            System.out.println("FileNotFoundException Occurred" + e.getMessage());
        } catch (IOException e) {
            System.out.println("IOException Occurred" + e.getMessage());
        }
        //setLineNum(lines);
       return lines;
	}

	@Override
	public boolean getCsvFile() {
		// TODO Auto-generated method stub
		//String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrUser.csv";
        File file = new File(userDbPath);
        FileReader fr = null;
		try {
			fr = new FileReader(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			return false;
		}
        BufferedReader brcsv = new BufferedReader(fr);
		return true;
	}
	public String addUserToCsv(HotelUser hu, int lines) {
		String msg = null;
		FileWriter fw = null;
		
		   BufferedWriter bw = null;
		   try{
			   //String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrUser.csv";
		        fw = new FileWriter(new File(userDbPath),true);
		        bw = new BufferedWriter(fw);
		

			//fileWriter.append(CSV_HEADER);
			//fileWriter.append('\n');
		        //System.out.println("line num is inside addAdminToCsv method: "+ lines);
		        
				bw.append(String.valueOf(lines+1));
				bw.append(',');
				bw.append(hu.getName());
				bw.append(',');
				bw.append(hu.getRole());
				bw.append(',');
				bw.append(hu.getUsername());
				bw.append(',');
				bw.append(hu.getPassword());
				bw.append('\n');
				bw.close();
		
				msg = "INSERTED";
			//System.out.println("Write CSV successfully!");
		} catch (Exception e) {
			msg = "NOTINSERTED";
			System.out.println("Writing CSV error!");
			e.printStackTrace();
		} 
		   finally {
	           if(bw != null) {
	                try {
						bw.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	            }
	            if(fw != null) {
	                try {
						fw.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	            }
		   }
	
		return msg;
	}

	//get all user data
	   public List<HotelUser> getAllUsers() throws FileNotFoundException, IOException
	    {
	        List<HotelUser> AllUser = new ArrayList<HotelUser>();
	        try{
	        	//for local host
	            //String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrUser.csv";
	            
	        	//String userDbPath = System.getProperty("user.dir") +"\\OnlineHotelReservation"+ "\\ohrcommon"+"\\"+"ohrUser.csv";
	          //for tesla
	        	//String userDbPath = System.getProperty("user.dir")+ "/ohrcommon"+"/"+"ohrUser.csv";
	        	
	            File file = new File(userDbPath);
	            FileReader fr = new FileReader(file);
	            BufferedReader br = new BufferedReader(fr);
	            String line = "";
	            String[] tempArr;
	            int i = 0;
	            
	            while((line = br.readLine()) != null) {
	               //System.out.print(line+"\n");
	               tempArr = line.split(",");
	               if (i == 0)
	               {
	                   i++;
	                   continue;
	               }
	               else{
	                   HotelUser hus = new HotelUser(Integer.parseInt(tempArr[0]),tempArr[1],tempArr[2],tempArr[3],tempArr[4]);
	                   AllUser.add(hus);
	               }
	               i++;
	           }
	        }
	         catch(IOException ioe) {
	            ioe.printStackTrace();
	         }
	        return AllUser;
	    }
	   
	   // name or username wise object search the remove and write
	    public HotelUser getUser(String name, String username)
	    {
	        HotelUser hus = null;
	        List<HotelUser> AllUser = null;
	        UserDB ctrl =new UserDB();
	        try {
	        	AllUser = ctrl.getAllUsers();
	        } catch (IOException ex) {
	            Logger.getLogger(HotelUserController.class.getName()).log(Level.SEVERE, null, ex);
	        }
	            //System.out.print(AllUser.size());
	        /*System.out.println("before removing----");
	        for(HotelUser user: AllUser) {
	            System.out.println(user);  // Will invoke overrided `toString()` method
	        }
	        */
	        for (int i = 0; i< AllUser.size();i++)
	        {
	            if ((AllUser.get(i).getName().equalsIgnoreCase(name)) || (AllUser.get(i).getUsername().equalsIgnoreCase(username)))
	            {
	                hus = AllUser.get(i);
	                //System.out.println("print id of: "+name + ha.getAdmin_id()+"\n");
	                AllUser.remove(i);
	            }
	        }
	        /*
	        System.out.println("after removing----");
	        for(HotelUser user: AllUser) {
	            System.out.println(user);  // Will invoke overrided `toString()` method
	        }
	        */
	        if (hus!= null)
		       {
				   FileWriter fw = null;
					
				   BufferedWriter bw = null;
				   try{
					   //String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\firstTestJava"+"\\"+"ohrUser.csv";
				        fw = new FileWriter(new File(userDbPath),false);
				        bw = new BufferedWriter(fw);
			
				        fw.write(CSV_HEADER);
				        fw.write('\n');
			
					for (HotelUser user: AllUser) {
						fw.write(String.valueOf(user.getId()));
						fw.write(',');
						fw.write(String.valueOf(user.getName()));
						fw.write(',');
						fw.write(user.getRole());
						fw.write(',');
						fw.write(user.getUsername());
						fw.write(',');
						fw.write(user.getPassword());
						fw.write('\n');
					}
			
					//System.out.println("Write CSV successfully!");
				} catch (Exception e) {
					hus = null;
					System.out.println("Writing CSV error!");
					e.printStackTrace();
				} finally {
					try {
						fw.flush();
						fw.close();
					} catch (IOException e) {
						System.out.println("Flushing/closing error!");
						e.printStackTrace();
					}
				}
		        
		    }
	        return hus;
	    }
}
