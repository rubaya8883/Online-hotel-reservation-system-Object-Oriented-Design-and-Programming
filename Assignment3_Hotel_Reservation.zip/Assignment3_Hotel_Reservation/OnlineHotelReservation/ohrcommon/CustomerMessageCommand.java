/**
 * 
 */
package ohrcommon;

/**
 * @author Rubaya
 * Concrete Command class for customer
 *
 */
public class CustomerMessageCommand implements MessageCommand{
	MessageReceiver customer;
	public CustomerMessageCommand(MessageReceiver customer)
	{
		this.customer = customer;
	}
	@Override
	public void execute(String username) {
		// TODO Auto-generated method stub
		customer.loginMsgForCustomer(username);
	}
}
