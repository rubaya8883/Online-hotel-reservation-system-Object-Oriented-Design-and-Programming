/**
 * 
 */
package ohrcommon;

import java.util.Scanner;

/**
 * @author Rubaya
 * view of removing a customer from customer table and user table.
 *
 */
public class RemoveCustomerView implements ViewInterface{
	//concrete class
	@Override
	public String[] View()
	{
		System.out.println("--------------- Remove Customer----------------------- ");
        String[] cusRmvData = new String[3];
        System.out.print("Enter customer's name\n");
        
        Scanner scann = new Scanner(System.in);
        cusRmvData[0] = scann.nextLine();
        System.out.print("Enter customer's username\n");
        cusRmvData[1] = scann.nextLine();
        
        System.out.print("Enter Cellphone:\n");
        cusRmvData[2] = scann.nextLine();
        System.out.println("----------------------------------------------------- ");
		return cusRmvData;
		
	}

	@Override
	public void showMessage(String msg) {
		// TODO Auto-generated method stub
		System.out.println(msg + "\n");
	}
}
