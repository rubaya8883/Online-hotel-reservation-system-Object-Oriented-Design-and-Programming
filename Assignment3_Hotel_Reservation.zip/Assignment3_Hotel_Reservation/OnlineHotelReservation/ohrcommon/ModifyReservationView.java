/**
 * 
 */
package ohrcommon;

import java.util.Scanner;

/**
 * @author Rubaya
 * Modify reservation by from date,to date and reservation number.
 *
 */
public class ModifyReservationView implements ViewInterface{
	//concrete class
	@Override
	 public String[] View()
	    {
	    	System.out.println("--------------- Modify Reservation----------------------- ");
	    	String[] roomRdata = new String[3];
	        System.out.print("Enter From date (MM/dd/yyyy):\n");
	        Scanner obj = new Scanner(System.in);
	        roomRdata[0] = obj.nextLine();
	        System.out.print("Enter To date (MM/dd/yyyy):\n");
	        roomRdata[1] = obj.nextLine();
	        System.out.print("Enter reservation number:\n");
	        roomRdata[2] = obj.nextLine();
	        System.out.println("------------------------------------------------------");
	        return roomRdata;
	    }
	@Override
	public void showMessage(String msg) {
		// demo message
		// can not modify if reservation started,
		//if already other reservation will be in that date range
		System.out.println(msg + "\n");
        //System.out.println("Reservation successfully modified\n");
        System.out.println("------------------------------------------------------");
	}
}
