/**
 * 
 */
package ohrcommon;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author Rubaya
 * Controller class for hotel Reservation
 *
 */
public class HotelReservationController implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// place a reservation line, calling from placeReservation method of IOperationImpl 
	// calls roomDB.addReservationToCsv
	public String placeReservationLine(Date fromDate, Date toDate, String roomType)
	{
		String msg = null;
		String msg1 = null;
		int reservationNum = 0;
		boolean checkRoomCsv;
		boolean checkReservationCsv;
		int lines = 0;
		List<Integer> roomlist=new ArrayList<Integer>(); 
		RoomDB roomDB =new RoomDB();
		checkRoomCsv = roomDB.getCsvFile();
		checkReservationCsv = roomDB.getCsvFileReservation();
		if(checkRoomCsv && checkReservationCsv)
		{
			roomlist = roomDB.getRoomTypeList(roomType);
			if (roomlist.size()>0)
			{
				lines = roomDB.getLineNumber();
				msg1 = roomDB.addReservationToCsv(roomlist, lines, fromDate, toDate);
				if (msg1.equalsIgnoreCase("INSERTED"))
				{
					reservationNum = roomDB.getReservationNum();
					msg = "Reservation successfully done. Your reservation ID: " + reservationNum;
				}
				else if(msg1.equalsIgnoreCase("NOTINSERTED"))
				{
					msg = "Error occured! No reservation has been made.";
				}
				else if (msg1.equalsIgnoreCase("NOROOMAVAILABLE"))
				{
					msg = "No room available for booking within this date range and room type.";
				}
				
			}
			else
				msg = "Error! you have entered wrong room type. Please try again.";
		}
		else
			msg = "Error! No file found.";
		return msg;
		
		
	}
	// this method is called by cancelReservation method of the IOperationImpl class. this is 
	//responsible for cancelReservation. It checks wrong resrvation id as well as 
	// if a cancelation is required or not.Also pass messages to the caller method
	public String cancelReservation(int reservationNum, Date dateToday)
	{
		String msg = null;
		String msg1 = null;
		boolean checkReservationCsv;
		RoomDB roomDB =new RoomDB();
		checkReservationCsv = roomDB.getCsvFileReservation();
		if(checkReservationCsv)
		{
			msg1 = roomDB.cancelReservationLine(reservationNum, dateToday);
			if (msg1.equalsIgnoreCase("WRONGRESERVATIONID"))
			{
				msg = "You have entered wrong reservation id. Please try again.";
			}
			else if (msg1.equalsIgnoreCase("CANCANCELWITHCOST"))
			{
				msg = "Reservation successfully canceled. You need to pay some amount."+"\n cancelation is done 24 hrs of reservation date.";
			}
			else if (msg1.equalsIgnoreCase("CANNOTCANCEL"))
			{
				msg = "You can not cancel this reservation, as your reservation has already started.";
			}
			else if (msg1.equalsIgnoreCase("INSERTED"))
			{
				msg = "Successfully canceled the reservation.";
			}
		}
		else
			msg = "Error! No file found.";
		return msg;
	}
	// this method is for modify a reservation it checks correct reservation id 
	// fetch room num and type of the room to fetch room type list
	// calls roomDB.modifyReservation 
	public String modifyReservationLine(Date fromDate, Date toDate, int reservationNum)
	{
		String msg = null;
		String msg1 = null;
		String msg2 = null;
		int roomNum = 0;
		int lineNum = 0;
		String roomType = null;
		boolean checkRoomCsv;
		boolean checkReservationCsv;
		int lines = 0;
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		
		List<Integer> roomlist=new ArrayList<Integer>(); 
		RoomDB roomDB =new RoomDB();
		checkRoomCsv = roomDB.getCsvFile();
		checkReservationCsv = roomDB.getCsvFileReservation();
		if(checkRoomCsv && checkReservationCsv)
		{
			msg1 = roomDB.getRoomNumByReservationNum(reservationNum);
			msg2 = roomDB.getLineNumByReservationNum(reservationNum);
			//System.out.println("reservationid---:"+msg1 +"gap :"+msg2);
			if ((msg1.equalsIgnoreCase("NODATAFOUND")) && (msg2.equalsIgnoreCase("NODATAFOUND")))
			{
				msg = "Reservation ID is wrong. Please enter correct ID.";
			}
			else
			{
				roomNum = Integer.parseInt(msg1);
				lineNum = Integer.parseInt(msg2);
				
				roomType = roomDB.getRoomTypeByRoomNum(roomNum);
				Date todayd = new Date();
				//String stringTodayd = formatter.format(todayd);
				//System.out.println("date today:"+ stringTodayd);
				msg1 = roomDB.checkIfReservationStarted(reservationNum, todayd);
				if (msg1.equalsIgnoreCase("CANNOTMODIFY"))
				{
					msg = "Reservation already started, you can not modify it.";
				}
				else
				{
					roomlist = roomDB.getRoomTypeList(roomType);
					if (roomlist.size()>0)
					{
						//lines = roomDB.getLineNumber();
						msg1 = roomDB.modifyReservation(roomlist, reservationNum, lineNum, fromDate, toDate);
						if (msg1.equalsIgnoreCase("ERROR"))
						{
							msg = "Cannot modify this reservation.";
						}
						else if (msg1.equalsIgnoreCase("MODIFIED"))
						{
							msg = "Reservation successfully modified.";
						}
						else if (msg1.equalsIgnoreCase("NOROOMAVAILABLE"))
						{
							msg = "Reservation can not be modified, because no rooms available within this date range. ";
						}
					}
				}
				
			}
		}
		else 
			msg = "Error! No file found.";
		return msg;
	}
}
