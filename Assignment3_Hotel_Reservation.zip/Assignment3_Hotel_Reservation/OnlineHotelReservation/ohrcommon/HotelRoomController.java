/**
 * 
 */
package ohrcommon;

import java.util.List;



/**
 * @author Rubaya
 * * Controller class for hotel room
 * server side controller.
 *
 */
public class HotelRoomController implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public String updateRoom(String roomnum, String toupdate, String selection)
    {
		String msg = null;
		boolean check;
		HotelRoom hr = null;
		RoomDB roomDB =new RoomDB();
		check = roomDB.getCsvFile();
		if(check)
		{
			if(selection.equals("description"))
			{
				hr = roomDB.updateRoomByDescription(roomnum, toupdate);
				if(hr == null)
				{
					msg = "NOTFOUND";
				}
				else
				{
					msg = "FOUND";
				}
			}
			else if(selection.equals("price"))
			{
				hr = roomDB.updateRoomByPrice(roomnum, toupdate);
				if(hr == null)
				{
					msg = "NOTFOUND";
				}
				else
				{
					msg = "FOUND";
				}
			}
			else if(selection.equals("avalibility"))
			{
				hr = roomDB.updateRoomByAvalibility(roomnum, toupdate);
				if(hr == null)
				{
					msg = "NOTFOUND";
				}
				else
				{
					msg = "FOUND";
				}
			}
		}
		else
		{
			msg = "FILENOTFOUND";
		}
		return msg;
    }
	public List<HotelRoom> getSearchedRoomList(String searchField, String searchOption)
    {
		boolean check;
		HotelRoom hr = null;
		List<HotelRoom> AllRoomWithFilter = null;
		RoomDB roomDB =new RoomDB();
		check = roomDB.getCsvFile();
		if(check)
		{
			if(searchOption.equalsIgnoreCase("t"))
			{
				AllRoomWithFilter = roomDB.getRoomListByType(searchField);
			}
			else if(searchOption.equalsIgnoreCase("p"))
			{
				AllRoomWithFilter = roomDB.getRoomListByPrice(searchField);
			}
		}
		else
		{
			return AllRoomWithFilter;
		}
		return AllRoomWithFilter;
    
    }
}
