/**
 * 
 */
package ohrcommon;

/**
 * @author Rubaya
 * This is the factory producer class
 * Using the ViewFactoryProducer to get AbstractViewFactory in order to get factories 
 * of concrete classes by passing an information such as type.
 *
 */
public final class ViewFactoryProducer {
	
	private ViewFactoryProducer(){
		throw new AssertionError();
	}
	public static AbstractViewFactory getFactory(String factoryType){
		
		switch(factoryType)
		{
			case "ADMINFactory": return new AdminViewFactory();
			case "CUSTOMERFactory": return new CustomerViewFactory();
		}

		return null;
	}
}
