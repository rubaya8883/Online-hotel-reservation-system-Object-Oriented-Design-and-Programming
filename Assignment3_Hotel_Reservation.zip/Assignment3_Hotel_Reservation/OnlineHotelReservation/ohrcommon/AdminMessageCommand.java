/**
 * 
 */
package ohrcommon;

/**
 * @author Rubaya
 * Concrete Command class for admin
 *
 */
public class AdminMessageCommand implements MessageCommand{
	MessageReceiver admin;
	public AdminMessageCommand(MessageReceiver admin)
	{
		this.admin = admin;
	}
	@Override
	public void execute(String username) {
		// TODO Auto-generated method stub
		admin.loginMsgForAdmin(username);
	}
	
}
