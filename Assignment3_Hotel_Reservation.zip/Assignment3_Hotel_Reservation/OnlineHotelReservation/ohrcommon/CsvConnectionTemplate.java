/**
 * 
 */
package ohrcommon;

/**
 * @author Rubaya
 * abstract class for the template pattern
 *
 */
public abstract class CsvConnectionTemplate {
	public abstract int getLineNumber();
	public abstract boolean getCsvFile();
	private int lineNum;
	//template method
	public final String csvConnection()
	{
		String msg;
		int lines;
		boolean check;
		//check if the csv file exist?
		check = getCsvFile();
		
		if (check) {
			msg = "FOUND";
			lines = getLineNumber(); // find the total num of lines in the csv
			setLineNum(lines);
		}
		else msg = "NOTFOUND";
		return msg;
	}
	//getter method to get lineNum
	public int getLineNum() {
		//System.out.println("line num is inside get method: "+ lineNum);
		return lineNum;
	}
	//setter method to set lineNum
	public void setLineNum(int lineNum) {
		//System.out.println("line num is inside set method: "+ lineNum);
		this.lineNum = lineNum;
	}
}
