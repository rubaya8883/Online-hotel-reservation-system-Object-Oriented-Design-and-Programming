/**
 * 
 */
package ohrcommon;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Controller class for hotel user
 * server side controller.
 * @author Rubaya
 *
 */
public class HotelUserController implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    // this method is calling by registerAdmin, registerCustomer methods of IOperationImpl
	// it uses templete pattern method.
	public String addUser(HotelUser hus)
    {
		String msg = null;
		String msg2 = null;
		int line;
		CsvConnectionTemplate userDB = new UserDB();
		UserDB usrDB = new UserDB();
		msg = userDB.csvConnection();
		if (msg.equals("FOUND"))
		{
			line = userDB.getLineNum(); //this lineNum method is in CSvconnectionTemplete class
			msg2 = usrDB.addUserToCsv(hus, line);
			return msg2;
		}
		else
			return msg;
		//System.out.print("User added successfully! The actual addition to database is yet to be implemented.\n");
    }
    
 
    // checks the user login info is correct or not calling from IOperationImpl class
    public HotelUser getUserFromLogin(String usrName, String pass)
    {
    	//System.out.println("inside HotelUserController--------");
        HotelUser hus = null;
        List<HotelUser> AllUser = null;
        UserDB ctrl =new UserDB();
        boolean scheck = false;
        try {
            AllUser = ctrl.getAllUsers();
        } catch (IOException ex) {
            Logger.getLogger(HotelUserController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        for (int i = 0; i< AllUser.size();i++)
        {
            
            //System.out.print(AllUser.get(i).UserName + " " +AllUser.get(i).Password +"\n");
            if ((AllUser.get(i).getUsername().equals(usrName)) && (AllUser.get(i).getPassword().equals(pass)))
            {
                hus = AllUser.get(i);
                scheck = true;
                break;
            }
        }

        return hus;
    }
    
    /*
    public HotelUser getUser(int Id)
    {
        HotelUser hus = null;
        List<HotelUser> AllUser = null;
       UserDB ctrl =new UserDB();
        try {
            AllUser = ctrl.getAllUsers();
        } catch (IOException ex) {
            Logger.getLogger(HotelUserController.class.getName()).log(Level.SEVERE, null, ex);
        }
            //System.out.print(AllUser.size());
        for (int i = 0; i< AllUser.size();i++)
        {
            if (AllUser.get(i).getId() == Id)
            {
                hus = AllUser.get(i);
            }
        }
        return hus;
    }
    
    */
    // delete a user. calling from IOperationImpl class.It calls -usrDB.getUser method.
	public String deleteHotelUser(String name, String username)
	{
		String msg = null;
		boolean check;
		HotelUser hus = null;
		UserDB usrDB =new UserDB();
		check = usrDB.getCsvFile();
		if(check)
		{
			hus = usrDB.getUser(name, username);
			if (hus == null)
			{
				msg = "NOTFOUND";
			}
			else
			{
				msg = "FOUND";
			}
		}
		else
		{
			msg = "FILENOTFOUND";
		}
		
		return msg;
		
	}
	
}
