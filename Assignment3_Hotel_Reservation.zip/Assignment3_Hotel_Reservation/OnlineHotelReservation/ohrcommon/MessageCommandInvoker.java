/**
 * 
 */
package ohrcommon;

/**
 * @author Rubaya
 * It ia a invoker class for Command Pattern, It invokes the command and 
 * passes the request to command object to process it.
 *
 */
public class MessageCommandInvoker {
	private MessageCommand command;
	
	public MessageCommandInvoker() {
		
	}
	public void setMsgCommand(MessageCommand command) {
		this.command = command;
	}
	public void invokeCommand(String username) {
		command.execute(username);
	}
}
