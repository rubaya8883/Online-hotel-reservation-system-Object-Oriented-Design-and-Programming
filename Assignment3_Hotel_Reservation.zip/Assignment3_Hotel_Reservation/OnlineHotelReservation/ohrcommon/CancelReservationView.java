/**
 * 
 */
package ohrcommon;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 * @author Rubaya
 * cancel reservation according to reservation num
 *
 */
public class CancelReservationView implements ViewInterface{
	//concrete class
	SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");

	
	Date todayd = new Date();
	String stringTodayd = formatter.format(todayd);
	
	@Override
    public String[] View()
    {
    	System.out.println("--------------- Cancel Room Reservation----------------------- ");
        String[] revCanceldata = new String[2];
        System.out.print("Enter Reservation Num:\n");
        Scanner obj = new Scanner(System.in);
        revCanceldata[0] = obj.nextLine();
        revCanceldata[1] = stringTodayd;
        System.out.println("----------------------------------------------------------------");
        return revCanceldata;
    }
	@Override
	public void showMessage(String msg) {
		// demo message
		// 3 types of msg= can not cancel, cancel successful, may charge (if within 24hrs of reservation)
		System.out.println(msg + "\n");
        //System.out.println("Reservation has been successfully canceled\n");
        System.out.println("-----------------------------------------------------------------");
	}
}
