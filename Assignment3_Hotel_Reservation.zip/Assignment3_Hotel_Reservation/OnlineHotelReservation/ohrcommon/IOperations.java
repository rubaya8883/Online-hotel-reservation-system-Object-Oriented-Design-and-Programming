/**
 * 
 */
package ohrcommon;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Date;
import java.util.List;

/**
 * *Interface for the RMI remote object. It serves as the proxy between the HotelServer and the
 * HotelClient. The HotelServer must implement this method.
 * @author Rubaya
 *
 */
public interface IOperations extends Remote {
	public HotelUser login(String usrname, String pass) throws RemoteException;
    public String registerCustomer(HotelUser hus) throws RemoteException;
    public String registerAdmin(HotelUser hus) throws RemoteException;
    public String deleteCustomerUser(String name, String username) throws RemoteException;
    public String deleteAdminUser(String name, String username) throws RemoteException;
    //public HotelUser remRegister(String[] data) throws RemoteException;
    public List<HotelRoom> browseHotelRooms(String searchField, String searchOption) throws RemoteException;
    public String updateHotelRoom(String roomnum, String toupdate, String selection) throws RemoteException;
    public boolean approveHotelReservation(HotelReservation hr) throws RemoteException;
    public List<HotelReservation> getAllReservation(HotelUser hu) throws RemoteException;
    public HotelReservation getReservation(int reservationId) throws RemoteException;
    public String placeReservation(Date fromDate, Date toDate, String roomType) throws RemoteException;
    public String modifyReservation(Date fromDate, Date toDate, int reservationNum) throws RemoteException;
    public String cancelReservation(int reservationNum, Date dateToday) throws RemoteException;
    public String addAdmin(HotelAdmin had) throws RemoteException;
    public boolean updateAdmin(HotelUser hus,HotelAdmin had ) throws RemoteException;
    public String deleteAdmin(String name, String username, String cellphone) throws RemoteException;
    public String addCustomer(HotelCustomer hcs) throws RemoteException;
    public boolean updateCustomer(HotelUser hus,HotelCustomer hcs ) throws RemoteException;
    public String deleteCustomer(String name, String username, String cellphone) throws RemoteException;
    
    
}
