/**
 * 
 */
package ohrcommon;

/**
 *  HotelUser object (model object).
 * @author Rubaya
 *
 */
public class HotelUser implements java.io.Serializable{

	@Override
	public String toString() {
		return "HotelUser [id=" + id + ", name=" + name + ", role=" + role + ", username=" + username + ", password="
				+ password + "]";
	}


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    private int id;
    private String name;
    private String role;
    private String username;
    private String password;

    
    public HotelUser(int id,String name,String role,String username,String pass)
    {
        this.setId(id);
        this.setName(name);
        this.setRole(role);
        this.setPassword(pass);
        this.setUsername(username);
    }


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getRole() {
		return role;
	}


	public void setRole(String role) {
		this.role = role;
	}


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}
}
