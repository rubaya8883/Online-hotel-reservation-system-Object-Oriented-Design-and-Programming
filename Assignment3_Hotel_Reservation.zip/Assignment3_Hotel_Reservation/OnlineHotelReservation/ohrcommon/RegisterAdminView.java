/**
 * 
 */
package ohrcommon;

import java.util.Scanner;

/**
 * demo view of admin registration.
 * @author Rubaya
 *
 */
public class RegisterAdminView implements ViewInterface{
	//concrete class
	@Override
	public String[] View()
    {	System.out.println("----------------- Register Admin----------------------- ");
        String[] adminData = new String[7];
        System.out.print("Enter admin's name\n");
        
        Scanner scann = new Scanner(System.in);
        adminData[0] = scann.nextLine();
        System.out.print("Enter admin's username\n");
        adminData[1] = scann.nextLine();
        System.out.print("Enter Password:\n");
        adminData[2] = scann.nextLine();
        adminData[3] = "A";
        System.out.print("Enter zone:\n");
        adminData[4] = scann.nextLine();
        System.out.print("Enter Primary/Secondary (y/n):\n");
        adminData[5] = scann.nextLine();
        System.out.print("Enter Cellphone:\n");
        adminData[6] = scann.nextLine();
        System.out.println("---------------------------------------------------------");
        return adminData;
    }

	@Override
	public void showMessage(String msg) {
		// TODO Auto-generated method stub
		System.out.println(msg + "\n");
	}
}
