/**
 * 
 */
package ohrcommon;

/**
 * @author Rubaya
 * Receiver for the commands
 *
 */
public class MessageReceiver {
	public MessageReceiver() {
		
	}
	// generate login message for Admin user
	public void loginMsgForAdmin(String username)
	{
		System.out.print("Hello, " + username+ ", You have logged in as Admin\n");
	}
	// generate login message for Admin user
	public void loginMsgForCustomer(String username)
	{
		System.out.print("Hello, " + username+ ", You have logged in as Customer\n");
	}
}
