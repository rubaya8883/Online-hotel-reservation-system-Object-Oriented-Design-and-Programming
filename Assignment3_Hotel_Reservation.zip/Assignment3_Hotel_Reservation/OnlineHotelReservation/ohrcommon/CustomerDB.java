/**
 * 
 */
package ohrcommon;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Rubaya
 * Class for Customer data base implements base template class 
 *
 */
public class CustomerDB extends CsvConnectionTemplate{

	//for localhost
	//private static final String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrCustomer.csv";
    //for tesla
  	private static final String userDbPath = System.getProperty("user.dir")+ "/ohrcommon"+"/"+"ohrCustomer.csv";
	private static final String CSV_HEADER = "id,customer_id,name,creditcard,address,cellphone";
	// for getting the num of lines of the csv file (will use later for adding a line in csv)
	@Override
	public int getLineNumber() {
		// TODO Auto-generated method stub
		int lines = 0;
        
        try {
 
        	//String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrCustomer.csv";
            LineNumberReader lineNumberReader = new LineNumberReader(new FileReader(userDbPath));
            lineNumberReader.skip(Long.MAX_VALUE);
            lines = lineNumberReader.getLineNumber() - 1;
            lineNumberReader.close();
            
 
        } catch (FileNotFoundException e) {
            System.out.println("FileNotFoundException Occurred" + e.getMessage());
        } catch (IOException e) {
            System.out.println("IOException Occurred" + e.getMessage());
        }
        //setLineNum(lines);
       return lines;
	}

	// checking whether the csv file exist or not
	@Override
	public boolean getCsvFile() {
		// TODO Auto-generated method stub
		//String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrCustomer.csv";
        File file = new File(userDbPath);
        FileReader fr = null;
		try {
			fr = new FileReader(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			return false;
		}
        BufferedReader brcsv = new BufferedReader(fr);
		return true;
	}
	//adding customer to ohrcustomer.csv file.
	public String addCustomerToCsv(HotelCustomer hc, int lines) {
		String msg = null;
		FileWriter fw = null;
		
		   BufferedWriter bw = null;
		   try{
			   //String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrCustomer.csv";
		        fw = new FileWriter(new File(userDbPath),true);
		        bw = new BufferedWriter(fw);
		

			//fileWriter.append(CSV_HEADER);
			//fileWriter.append('\n');
		        //System.out.println("line num is inside addAdminToCsv method: "+ lines);
		        
				bw.append(String.valueOf(lines+1));
				bw.append(',');
				bw.append(String.valueOf(lines+201));
				bw.append(',');
				bw.append(hc.getName());
				bw.append(',');
				bw.append(hc.getCreditCard());
				bw.append(',');
				bw.append(hc.getAddress());
				bw.append(',');
				bw.append(hc.getCellPhone());
				bw.append('\n');
				bw.close();
		
				msg = "INSERTED";
			//System.out.println("Write CSV successfully!");
		} catch (Exception e) {
			msg = "NOTINSERTED";
			System.out.println("Writing CSV error!");
			e.printStackTrace();
		} 
		   finally {
	           if(bw != null) {
	                try {
						bw.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	            }
	            if(fw != null) {
	                try {
						fw.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	            }
		   }
	
		return msg;
	}
	
//csv to arraylist get all customer data
	
    public List<HotelCustomer> getAllCustomer() throws FileNotFoundException, IOException
    {
        List<HotelCustomer> AllCustomer = new ArrayList<HotelCustomer>();
        try{
        	// for local host
            //String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrAdmin.csv";
            // for tesla
            
        	//String userDbPath = System.getProperty("user.dir") +"\\OnlineHotelReservation"+ "\\ohrcommon"+"\\"+"ohrUser.csv";
          //for tesla
        	//String userDbPath = System.getProperty("user.dir")+ "/ohrcommon"+"/"+"ohrUser.csv";
        	
            File file = new File(userDbPath);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line = "";
            String[] tempArr;
            int i = 0;
            
            while((line = br.readLine()) != null) {
               //System.out.print(line+"\n");
               tempArr = line.split(",");
               if (i == 0)
               {
                   i++;
                   continue;
               }
               else{
            	   HotelCustomer hc = new HotelCustomer(Integer.parseInt(tempArr[0]),Integer.parseInt(tempArr[1]),tempArr[2],tempArr[3],tempArr[4],tempArr[5]);
            	   AllCustomer.add(hc);
               }
               i++;
           }
        }
         catch(IOException ioe) {
            ioe.printStackTrace();
         }
        return AllCustomer;
    }
   // name or phoneNum wise object search then remove and write (remove customer)
    // any one of the info should be correct (no need to be both)
    public HotelCustomer getCustomer(String name, String cellphone)
    {
    	HotelCustomer hc = null;
        List<HotelCustomer> AllCustomer = null;
        CustomerDB ctrl =new CustomerDB();
        try {
        	AllCustomer = ctrl.getAllCustomer();
        } catch (IOException ex) {
            Logger.getLogger(HotelUserController.class.getName()).log(Level.SEVERE, null, ex);
        }
            //System.out.print(AllUser.size());
        /*System.out.println("before removing----");
        for(HotelCustomer customer: AllCustomer) {
            System.out.println(customer);  // Will invoke overrided `toString()` method
        }
        */
        for (int i = 0; i< AllCustomer.size();i++)
        {
            if ((AllCustomer.get(i).getName().equalsIgnoreCase(name)) || (AllCustomer.get(i).getCellPhone().equalsIgnoreCase(cellphone)))
            {
                hc = AllCustomer.get(i);
                //System.out.println("print id of: "+name + ha.getAdmin_id()+"\n");
                AllCustomer.remove(i);
            }
        }
        /*
        for(HotelCustomer customer: AllCustomer) {
            System.out.println(customer);  // Will invoke overrided `toString()` method
        }
        */
        if (hc!= null)
	       {
			   FileWriter fw = null;
				
			   BufferedWriter bw = null;
			   try{
				   //String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\firstTestJava"+"\\"+"ohrUser.csv";
			        fw = new FileWriter(new File(userDbPath),false);
			        bw = new BufferedWriter(fw);
		
			        fw.write(CSV_HEADER);
			        fw.write('\n');
		
				for (HotelCustomer customer: AllCustomer) {
					fw.write(String.valueOf(customer.getId()));
					fw.write(',');
					fw.write(String.valueOf(customer.getCustomer_id()));
					fw.write(',');
					fw.write(customer.getName());
					fw.write(',');
					fw.write(customer.getCreditCard());
					fw.write(',');
					fw.write(customer.getAddress());
					fw.write(',');
					fw.write(customer.getCellPhone());
					fw.write('\n');
				}
		
				//System.out.println("Write CSV successfully!");
			} catch (Exception e) {
				hc = null;
				System.out.println("Writing CSV error!");
				e.printStackTrace();
			} finally {
				try {
					fw.flush();
					fw.close();
				} catch (IOException e) {
					System.out.println("Flushing/closing error!");
					e.printStackTrace();
				}
			}
	        
	    }
        return hc;
    }
}
