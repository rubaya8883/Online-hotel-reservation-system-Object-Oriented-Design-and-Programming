/**
 * 
 */
package ohrcommon;

/**
 * @author Rubaya 
 * Command Interface
 *All the commands has to implement this interface
 */
public interface MessageCommand {
	public void execute(String username);
}
