/**
 * 
 */
package ohrcommon;

import java.util.Scanner;

/**
 * user login view.
 * @author Rubaya
 *
 */
public class UserLoginView {
    
	public String[] View()
    {
        String userData[] = {"",""};
        System.out.print("Please enter username:\n");
        
        Scanner obj = new Scanner(System.in);
        userData[0] = obj.nextLine();

        System.out.print("Please enter password:\n");
        userData[1] = obj.nextLine();
        
        //System.out.print("Please enter user role(A for Admin/ C for Customer):\n");
        //userData[2] = obj.nextLine();
        
        return userData;
    }
}
