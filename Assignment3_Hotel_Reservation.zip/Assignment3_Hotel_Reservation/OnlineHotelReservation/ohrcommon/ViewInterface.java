/**
 * 
 */
package ohrcommon;

/**
 * @author HP
 * Create an interface for Views
 *
 */
public interface ViewInterface {
	public String[] View();
	public void showMessage(String msg);
}
