/**
 * 
 */
package ohrcommon;

/**
 * @author Rubaya
 * Create ViewFactory classes extending AbstractViewFactory 
 * to generate object of concrete class based on given information.
 *
 */
public class CustomerViewFactory implements AbstractViewFactory{

	@Override
	public ViewInterface getViewInstance(String viewType) {
		// TODO Auto-generated method stub
		switch(viewType)
		{
			case "ROOMBROWSER": return new HotelRoomBrowserView();
			case "RESERVATION": return new HotelReservationView();
			case "MODIFYRESERV": return new ModifyReservationView();
			case "CANCELRESERV": return new CancelReservationView();
		}
		return null;
	}

}
