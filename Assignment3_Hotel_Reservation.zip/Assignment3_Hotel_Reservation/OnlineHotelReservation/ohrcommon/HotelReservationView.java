/**
 * 
 */
package ohrcommon;

import java.util.List;
import java.util.Scanner;

/**
 * demo view of room reservation according to date range and room number.
 * @author Rubaya
 *
 */
public class HotelReservationView implements ViewInterface{
	//concrete class
	@Override
    public String[] View()
    {
    	System.out.println("--------------- Room Reservation----------------------- ");
    	String[] roomRdata = new String[3];
        System.out.print("Enter From date (MM/dd/yyyy) :\n");
        Scanner obj = new Scanner(System.in);
        roomRdata[0] = obj.nextLine();
        System.out.print("Enter To date (MM/dd/yyyy) :\n");
        roomRdata[1] = obj.nextLine();
        System.out.print("Enter room type (suite/single/double):\n");
        roomRdata[2] = obj.nextLine();
        System.out.println("------------------------------------------------------");
        return roomRdata;
    }
	@Override
	public void showMessage(String msg) {
		// demo message
		System.out.println(msg + "\n");
        //System.out.println("Room is available for booking:\n");
        System.out.println("------------------------------------------------------");
	}
}
