/**
 * 
 */
package ohrcommon;

import java.util.List;
import java.util.Scanner;



/**
 *  view of showing list of rooms .
 * @author Rubaya
 *
 */
public class RoomView {
	// showing all rooms according to search criteria.
	public void showRoomList(List<HotelRoom> rooms) {
        for(HotelRoom room: rooms) {
            System.out.println(room);  // Will invoke overrided `toString()` method
        }
        System.out.println("---------------------------------------------------------");
        }
	
}
