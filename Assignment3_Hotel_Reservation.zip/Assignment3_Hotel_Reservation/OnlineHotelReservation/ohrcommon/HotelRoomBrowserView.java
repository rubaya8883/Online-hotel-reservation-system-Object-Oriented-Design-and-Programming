/**
 * 
 */
package ohrcommon;

import java.util.List;
import java.util.Scanner;

/**
 * demo view of browsing room availability according to price, room type.
 * @author Rubaya
 *
 */
public class HotelRoomBrowserView implements ViewInterface{
	//concrete class
	@Override
    public String[] View()
    {
		boolean isExit = false;
		Integer operationA = null;
		String[] roomBdata = new String[2];
		
		while(!isExit)
		{
			System.out.println("--------------- Browse Rooms----------------------- ");
			System.out.println("1. Browsing room by room type ");
			System.out.println("2. Browsing room by price ");
			System.out.print("3. Exit\n");
			System.out.println("--------------------------------------------------");
			System.out.println("Select an option to continue\n");
			Scanner scan1 = new Scanner(System.in);
			operationA = scan1.nextInt();
			if (operationA.equals(1)){
		      
				System.out.print("Enter room type (suite/single/double):\n");
				Scanner scann = new Scanner(System.in);
				roomBdata[0] = scann.nextLine();
		        
				roomBdata[1] = "t";
		        isExit = true;
			}
			else if (operationA.equals(2)){
			    System.out.print("Enter room price(atleast):\n");
			    Scanner scann = new Scanner(System.in);
			    roomBdata[0] = scann.nextLine();
			        
			    roomBdata[1] = "p";
			    
		        isExit = true;
			}
			else if(operationA.equals(3)){
				isExit = true;
			}
			else {
				System.out.println("Invalid input.");
			}
		}
		return roomBdata;
		
/*
		System.out.println("--------------- Browse Rooms----------------------- ");
		System.out.println("1. Browsing room by room type ");
		System.out.println("2. Browsing room by price ");
		System.out.print("3. Exit\n");
		System.out.println("--------------------------------------------------");
		System.out.println("Select an option to continue\n");
		Scanner scan1 = new Scanner(System.in);
		operationA = scan1.nextInt();
		switch (operationA)
		{
		case 1:
			System.out.print("Enter room type (suit/single/double):\n");
	        
			roomBdata[0] = scan1.nextLine();
	        
			roomBdata[1] = "t";
			break;
		
		case 2:
		      
		    System.out.print("Enter room price\n");
		    roomBdata[0] = scan1.nextLine();
		        
		    roomBdata[1] = "p";
		    break;
			
    	case 3:
    		System.out.println("Invalid input.");
    		break;
		default:
             System.out.println("Invalid input.");
             break;
		}
		return roomBdata;
		*/
		
    }

	@Override
	public void showMessage(String msg) {
		// TODO Auto-generated method stub
		System.out.println(msg + "\n");
	}
}
