/**
 * 
 */
package ohrcommon;

import java.util.Scanner;

/**
 * @author Rubaya
 * View for room update by admin 
 *
 */
public class UpdateRoomView implements ViewInterface{
	//concrete class
	@Override
	public String[] View()
	{
		boolean isExit = false;
		Integer operationA = null;
		String[] updateRoomData = new String[3];
		while(!isExit)
		{
			System.out.println("--------------- Update Room----------------------- ");
			System.out.println("1. Updating room description ");
			System.out.println("2. Updating room price");
			System.out.println("3. Updating room availability");
			System.out.print("4. Exit\n");
			System.out.println("--------------------------------------------------");
			System.out.println("Select an option to continue\n");
			Scanner scan1 = new Scanner(System.in);
			operationA = scan1.nextInt();
			if (operationA.equals(1)){
		      
		        System.out.print("Enter room number:\n");
		        
		        Scanner scann = new Scanner(System.in);
		        updateRoomData[0] = scann.nextLine();
		        
		        System.out.print("Enter description\n");
		        updateRoomData[1] = scann.nextLine();
		        
		        updateRoomData[2] = "description";
				//return updateRoomData;
		        isExit = true;
			}
			else if (operationA.equals(2)){
		        System.out.print("Enter room number:\n");
		        
		        Scanner scann = new Scanner(System.in);
		        updateRoomData[0] = scann.nextLine();
		        
		        System.out.print("Enter new price\n");
		        updateRoomData[1] = scann.nextLine();
		        
		        updateRoomData[2] = "price";
				//return updateRoomData;
		        isExit = true;
			}
			else if (operationA.equals(3)){
		        System.out.print("Enter room number:\n");
		        
		        Scanner scann = new Scanner(System.in);
		        updateRoomData[0] = scann.nextLine();
		        
		        System.out.print("Update room avalibility for today(y/n)\n");
		        updateRoomData[1] = scann.nextLine();
		        
		        updateRoomData[2] = "avalibility";
				//return updateRoomData;
		        isExit = true;
			}
			else if(operationA.equals(4)){
				isExit = true;
			}
			else {
				System.out.println("Invalid input.");
			}
		}
		return updateRoomData;
		
	}

	@Override
	public void showMessage(String msg) {
		// TODO Auto-generated method stub
		System.out.println(msg + "\n");
	}
}
