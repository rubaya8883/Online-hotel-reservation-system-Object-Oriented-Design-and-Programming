/**
 * 
 */
package ohrcommon;

/**
 * @author Rubaya
 * Create ViewFactory classes extending AbstractViewFactory 
 * to generate object of concrete class based on given information.
 *
 */
public class AdminViewFactory implements AbstractViewFactory{

	@Override
	public ViewInterface getViewInstance(String viewType) {
		// TODO Auto-generated method stub
		switch(viewType)
		{
			case "ADDADMIN": return new RegisterAdminView();
			case "ADDCUSTOMER": return new RegisterCustomerView();
			case "REMOVADMIN": return new RemoveAdminView();
			case "REMOVCUSTOMER": return new RemoveCustomerView();
			case "UPDATEROOM": return new UpdateRoomView();
		}
		return null;
	}

}
