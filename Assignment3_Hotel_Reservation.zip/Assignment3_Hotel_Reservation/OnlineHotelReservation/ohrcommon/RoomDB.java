/**
 * 
 */
package ohrcommon;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.LineNumberReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * @author Rubaya
 *This class is the database layer to handle room data base table and hotel reservation table.
 */
public class RoomDB {
	//for localhost
	//private static final String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrRoom.csv";
	//private static final String userDbPathR = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrReservation.csv";
    //for tesla
  	private static final String userDbPath = System.getProperty("user.dir")+ "/ohrcommon"+"/"+"ohrRoom.csv";
	private static final String userDbPathR = System.getProperty("user.dir")+ "/ohrcommon"+"/"+"ohrReservation.csv";
	
	private static final String CSV_HEADER = "id,roomNumber,dailyRate,type,description,price,quality,beds,status,isAvailable";
	private static final String CSV_HEADER_RESERVATION = "id,reservationId,roomId,fromDate,toDate";
	private int reservationNum = 0;
	//check the csv file (present or not). this is for ohrRoom.csv
	public boolean getCsvFile() {
		// TODO Auto-generated method stub
		
        File file = new File(userDbPath);
        FileReader fr = null;
		try {
			fr = new FileReader(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			return false;
		}
        BufferedReader brcsv = new BufferedReader(fr);
		return true;
	}

	//check the csv file (present or not). this is for ohrReservation.csv
	public boolean getCsvFileReservation() {
		// TODO Auto-generated method stub
		
        File file = new File(userDbPathR);
        FileReader fr = null;
		try {
			fr = new FileReader(file);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			return false;
		}
        BufferedReader brcsv = new BufferedReader(fr);
		return true;
	}
	
	//list of all rooms of hotel rooms. fatching data from ohrRoom.csv to array list
   public List<HotelRoom> getAllRooms() throws FileNotFoundException, IOException
    {
        List<HotelRoom> AllRoom = new ArrayList<HotelRoom>();
        try{
        	//for local host
            //String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrUser.csv";
            
        	//String userDbPath = System.getProperty("user.dir") +"\\OnlineHotelReservation"+ "\\ohrcommon"+"\\"+"ohrUser.csv";
          //for tesla
        	//String userDbPath = System.getProperty("user.dir")+ "/ohrcommon"+"/"+"ohrUser.csv";
        	
            File file = new File(userDbPath);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line = "";
            String[] tempArr;
            int i = 0;
            
            while((line = br.readLine()) != null) {
               //System.out.print(line+"\n");
               tempArr = line.split(",");
               if (i == 0)
               {
                   i++;
                   continue;
               }
               else{
            	   HotelRoom hus = new HotelRoom(Integer.parseInt(tempArr[0]),Integer.parseInt(tempArr[1]),Integer.parseInt(tempArr[2]),tempArr[3],tempArr[4],Integer.parseInt(tempArr[5]),Integer.parseInt(tempArr[6]),Integer.parseInt(tempArr[7]),tempArr[8],tempArr[9]);
            	   AllRoom.add(hus);
               }
               i++;
           }
        }
         catch(IOException ioe) {
            ioe.printStackTrace();
         }
        return AllRoom;
    }
   //list of all reservations of hotel rooms. fatching data from ohrReservation.csv to array list
   public List<HotelReservation> getAllReservation() throws FileNotFoundException, IOException
   {
       List<HotelReservation> AllReservation = new ArrayList<HotelReservation>();
       try{
       	
           File file = new File(userDbPathR);
           FileReader fr = new FileReader(file);
           BufferedReader br = new BufferedReader(fr);
           String line = "";
           String[] tempArr;
           int i = 0;
           DateFormat df = new SimpleDateFormat("MM/dd/yyyy"); 
           
           while((line = br.readLine()) != null) {
              //System.out.print(line+"\n");
              tempArr = line.split(",");
              if (i == 0)
              {
                  i++;
                  continue;
              }
              else{
           	   HotelReservation hus = new HotelReservation(Integer.parseInt(tempArr[0]),Integer.parseInt(tempArr[1]),Integer.parseInt(tempArr[2]),df.parse(tempArr[3]),df.parse(tempArr[4]));
           	AllReservation.add(hus);
              }
              i++;
          }
       }
        catch(IOException ioe) {
           ioe.printStackTrace();
        } catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
       return AllReservation;
   }
   //Type wise room list
   public List<Integer> getRoomTypeList(String type)
   {
	   List<Integer> listRoomType=new ArrayList<Integer>(); 
       List<HotelRoom> AllRoom = null;
       RoomDB ctrl =new RoomDB();
       int roomNum = 0;
       try {
       	AllRoom = ctrl.getAllRooms();
       } catch (IOException ex) {
           Logger.getLogger(HotelRoomController.class.getName()).log(Level.SEVERE, null, ex);
       }
       for (int i = 0; i< AllRoom.size();i++)
       {
           if (AllRoom.get(i).getType().equals(type))
           {

        	   roomNum = AllRoom.get(i).getRoomNumber();
        	   listRoomType.add(roomNum);
           }
       }
	   return listRoomType;
   }
   //for getting total number of lines of the ohrReservation.csv file
   // totalNum of lines are required when adding new lines of the ohrReservation.csv file
   public int getLineNumber() {
		// TODO Auto-generated method stub
	   int lines = 0;
        
        try {
 
        	//String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrCustomer.csv";
            LineNumberReader lineNumberReader = new LineNumberReader(new FileReader(userDbPathR));
            lineNumberReader.skip(Long.MAX_VALUE);
            lines = lineNumberReader.getLineNumber() - 1;
            lineNumberReader.close();
            
 
        } catch (FileNotFoundException e) {
            System.out.println("FileNotFoundException Occurred" + e.getMessage());
        } catch (IOException e) {
            System.out.println("IOException Occurred" + e.getMessage());
        }
        //setLineNum(lines);
       return lines;
	}
// getter method for reservation num
	public int getReservationNum() {
		//System.out.println("Reservation num is inside set method: "+ reservationNum);
		
		return reservationNum;
	}
	// setter method for reservation num
	public void setReservationNum(int revNum) {
		//System.out.println("line num is inside set method: "+ lineNum);
		//System.out.println("Reservation num is inside set method: "+ revNum);
		this.reservationNum = revNum;
	}
	// adding a new reservation line to ohrReservation.csv table. 
	// checks room type, then checks date range to the csv entry date range,
	// if overlaps date range then checks other rooms of same type, if other rooms of the
	// same type available in the roomtypelist then select the min num of rooms from them and
	// make a reservation for that.
	public String addReservationToCsv(List<Integer> roomlist, int lines, Date fromDate, Date toDate) {
		HotelReservation hrev = null;
        List<HotelReservation> AllReservation = null;
        RoomDB ctrl =new RoomDB();
        int flag =0;
        //int roomNum = 0;
        int minRoomNum = 0;
        String msg = null;
		FileWriter fw = null;
		
		BufferedWriter bw = null;
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy"); 
		HotelReservationController hrc = new HotelReservationController();
        // Clone the list
        List<Integer> cloned_list_roomlist = new ArrayList<Integer>(roomlist);
       // System.out.println("ArrayList contains cloned_list_roomlist: " + cloned_list_roomlist);

        try {
        	AllReservation = ctrl.getAllReservation();
        } catch (IOException ex) {
            Logger.getLogger(HotelRoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
		

		for (int j = 0; j< roomlist.size();j++)
		{
			//System.out.println("room list size :"+roomlist.size());
			for (int i = 0; i< AllReservation.size();i++)
			{
				if(AllReservation.get(i).getRoomId() == roomlist.get(j))
				{
					//System.out.println("room num count now :"+roomlist.get(j));
					if((AllReservation.get(i).getFromDate().equals(fromDate)) && (AllReservation.get(i).getToDate().equals(toDate)))
					{
						flag = flag+1;
						cloned_list_roomlist.remove(roomlist.get(j));
						break;
					}
					else if(AllReservation.get(i).getFromDate().equals(fromDate))
					{
						cloned_list_roomlist.remove(roomlist.get(j));
						break;
					}
					else if(AllReservation.get(i).getFromDate().equals(toDate))
					{	//System.out.println("todate> ");
						cloned_list_roomlist.remove(roomlist.get(j));
						break;
					}
					else if(AllReservation.get(i).getToDate().equals(toDate))
					{
						cloned_list_roomlist.remove(roomlist.get(j));
						break;
					}
					else if(AllReservation.get(i).getToDate().equals(fromDate))
					{    
						cloned_list_roomlist.remove(roomlist.get(j));
						break;
					}
					else if ((AllReservation.get(i).getFromDate().after(fromDate))&&(AllReservation.get(i).getToDate().after(toDate)))
					{
						flag = flag+1;
						cloned_list_roomlist.remove(roomlist.get(j));
						break;
					}
					else if((AllReservation.get(i).getFromDate().before(fromDate))&&(AllReservation.get(i).getToDate().after(toDate)))
					{
						flag = flag+1;
						cloned_list_roomlist.remove(roomlist.get(j));
						break;
					}
					else if(AllReservation.get(i).getFromDate().before(fromDate)&&(AllReservation.get(i).getToDate().before(toDate)))
					{
						flag = flag+1;
						cloned_list_roomlist.remove(roomlist.get(j));
						break;
					}
					
				}
			}

		}
		
		if(cloned_list_roomlist.size()>0)
		{
		//System.out.println("ArrayList contains : " + cloned_list_roomlist);
		   minRoomNum = Collections.min(cloned_list_roomlist);
		   //System.out.println("Minimum element : " + Collections.min(cloned_list_roomlist));
		   hrev = new HotelReservation(0,0,minRoomNum,fromDate,toDate);
		   try{
			   //String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrCustomer.csv";
		        fw = new FileWriter(new File(userDbPathR),true);
		        bw = new BufferedWriter(fw);
		
		        
				bw.append(String.valueOf(lines+1));
				bw.append(',');
				bw.append(String.valueOf(lines+1001));
				bw.append(',');
				bw.append(String.valueOf(hrev.getRoomId()));
				bw.append(',');
				bw.append(df.format(hrev.getFromDate()));
				bw.append(',');
				bw.append(df.format(hrev.getToDate()));
		
				bw.append('\n');
				bw.close();
		
				msg = "INSERTED";
				setReservationNum(lines+1001);
			//System.out.println("Write CSV successfully!");
		} catch (Exception e) {
			msg = "NOTINSERTED;";
			System.out.println("Writing CSV error!");
			e.printStackTrace();
		} 
		   finally {
	           if(bw != null) {
	                try {
						bw.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	            }
	            if(fw != null) {
	                try {
						fw.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	            }
		   }
		}
		else
		{
			msg = "NOROOMAVAILABLE";
		}
		return msg;
	}
   // description wise object search and write
    public HotelRoom updateRoomByDescription(String roomnum, String description)
    {
    	HotelRoom hr = null;
        List<HotelRoom> AllRoom = null;
        RoomDB ctrl =new RoomDB();
        try {
        	AllRoom = ctrl.getAllRooms();
        } catch (IOException ex) {
            Logger.getLogger(HotelRoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
            //System.out.print(AllUser.size());
        /*System.out.println("before removing----");
        for(HotelUser user: AllUser) {
            System.out.println(user);  // Will invoke overrided `toString()` method
        }
        */
        for (int i = 0; i< AllRoom.size();i++)
        {
            if (AllRoom.get(i).getRoomNumber() == Integer.parseInt(roomnum))
            {
                hr = AllRoom.get(i);
                //System.out.println("print id of: "+name + ha.getAdmin_id()+"\n");
                AllRoom.get(i).setDescription(description);
            }
        }
        /*
        System.out.println("after removing----");
        for(HotelUser user: AllUser) {
            System.out.println(user);  // Will invoke overrided `toString()` method
        }
        */
        if (hr!= null)
	       {
			   FileWriter fw = null;
				
			   BufferedWriter bw = null;
			   try{
				   //String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\firstTestJava"+"\\"+"ohrUser.csv";
			        fw = new FileWriter(new File(userDbPath),false);
			        bw = new BufferedWriter(fw);
		
			        fw.write(CSV_HEADER);
			        fw.write('\n');
		
				for (HotelRoom room: AllRoom) {
					fw.write(String.valueOf(room.getId()));
					fw.write(',');
					fw.write(String.valueOf(room.getRoomNumber()));
					fw.write(',');
					fw.write(String.valueOf(room.getDailyRate()));
					fw.write(',');
					fw.write(room.getType());
					fw.write(',');
					fw.write(room.getDescription());
					fw.write(',');
					fw.write(String.valueOf(room.getPrice()));
					fw.write(',');
					fw.write(String.valueOf(room.getQuality()));
					fw.write(',');
					fw.write(String.valueOf(room.getBeds()));
					fw.write(',');
					fw.write(room.getStatus());
					fw.write(',');
					fw.write(room.isAvailable());
					fw.write('\n');
				}
		
				//System.out.println("Write CSV successfully!");
			} catch (Exception e) {
				hr = null;
				System.out.println("Writing CSV error!");
				e.printStackTrace();
			} finally {
				try {
					fw.flush();
					fw.close();
				} catch (IOException e) {
					System.out.println("Flushing/closing error!");
					e.printStackTrace();
				}
			}
	        
	    }
        return hr;
    }
    // room avalibility wise object search and write
    public HotelRoom updateRoomByAvalibility(String roomnum, String avalibility)
    {
    	HotelRoom hr = null;
        List<HotelRoom> AllRoom = null;
        RoomDB ctrl =new RoomDB();
        try {
        	AllRoom = ctrl.getAllRooms();
        } catch (IOException ex) {
            Logger.getLogger(HotelRoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
            //System.out.print(AllUser.size());
        /*System.out.println("before removing----");
        for(HotelUser user: AllUser) {
            System.out.println(user);  // Will invoke overrided `toString()` method
        }
        */
        for (int i = 0; i< AllRoom.size();i++)
        {
            if (AllRoom.get(i).getRoomNumber() == Integer.parseInt(roomnum))
            {
                hr = AllRoom.get(i);
                //System.out.println("print id of: "+name + ha.getAdmin_id()+"\n");
                AllRoom.get(i).setAvailable(avalibility);
            }
        }
        /*
        System.out.println("after removing----");
        for(HotelUser user: AllUser) {
            System.out.println(user);  // Will invoke overrided `toString()` method
        }
        */
        if (hr!= null)
	       {
			   FileWriter fw = null;
				
			   BufferedWriter bw = null;
			   try{
				   //String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\firstTestJava"+"\\"+"ohrUser.csv";
			        fw = new FileWriter(new File(userDbPath),false);
			        bw = new BufferedWriter(fw);
		
			        fw.write(CSV_HEADER);
			        fw.write('\n');
		
				for (HotelRoom room: AllRoom) {
					fw.write(String.valueOf(room.getId()));
					fw.write(',');
					fw.write(String.valueOf(room.getRoomNumber()));
					fw.write(',');
					fw.write(String.valueOf(room.getDailyRate()));
					fw.write(',');
					fw.write(room.getType());
					fw.write(',');
					fw.write(room.getDescription());
					fw.write(',');
					fw.write(String.valueOf(room.getPrice()));
					fw.write(',');
					fw.write(String.valueOf(room.getQuality()));
					fw.write(',');
					fw.write(String.valueOf(room.getBeds()));
					fw.write(',');
					fw.write(room.getStatus());
					fw.write(',');
					fw.write(room.isAvailable());
					fw.write('\n');
				}
		
				//System.out.println("Write CSV successfully!");
			} catch (Exception e) {
				hr = null;
				System.out.println("Writing CSV error!");
				e.printStackTrace();
			} finally {
				try {
					fw.flush();
					fw.close();
				} catch (IOException e) {
					System.out.println("Flushing/closing error!");
					e.printStackTrace();
				}
			}
	        
	    }
        return hr;
    }
    // price wise object search and write
    public HotelRoom updateRoomByPrice(String roomnum, String price)
    {
    	HotelRoom hr = null;
        List<HotelRoom> AllRoom = null;
        RoomDB ctrl =new RoomDB();
        try {
        	AllRoom = ctrl.getAllRooms();
        } catch (IOException ex) {
            Logger.getLogger(HotelRoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
            //System.out.print(AllUser.size());
        /*System.out.println("before removing----");
        for(HotelUser user: AllUser) {
            System.out.println(user);  // Will invoke overrided `toString()` method
        }
        */
        for (int i = 0; i< AllRoom.size();i++)
        {
            if (AllRoom.get(i).getRoomNumber() == Integer.parseInt(roomnum))
            {
                hr = AllRoom.get(i);
                //System.out.println("print id of: "+name + ha.getAdmin_id()+"\n");
                AllRoom.get(i).setPrice(Integer.parseInt(price));
            }
        }
        /*
        System.out.println("after removing----");
        for(HotelUser user: AllUser) {
            System.out.println(user);  // Will invoke overrided `toString()` method
        }
        */
        if (hr!= null)
	       {
			   FileWriter fw = null;
				
			   BufferedWriter bw = null;
			   try{
				   //String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\firstTestJava"+"\\"+"ohrUser.csv";
			        fw = new FileWriter(new File(userDbPath),false);
			        bw = new BufferedWriter(fw);
		
			        fw.write(CSV_HEADER);
			        fw.write('\n');
		
				for (HotelRoom room: AllRoom) {
					fw.write(String.valueOf(room.getId()));
					fw.write(',');
					fw.write(String.valueOf(room.getRoomNumber()));
					fw.write(',');
					fw.write(String.valueOf(room.getDailyRate()));
					fw.write(',');
					fw.write(room.getType());
					fw.write(',');
					fw.write(room.getDescription());
					fw.write(',');
					fw.write(String.valueOf(room.getPrice()));
					fw.write(',');
					fw.write(String.valueOf(room.getQuality()));
					fw.write(',');
					fw.write(String.valueOf(room.getBeds()));
					fw.write(',');
					fw.write(room.getStatus());
					fw.write(',');
					fw.write(room.isAvailable());
					fw.write('\n');
				}
		
				//System.out.println("Write CSV successfully!");
			} catch (Exception e) {
				hr = null;
				System.out.println("Writing CSV error!");
				e.printStackTrace();
			} finally {
				try {
					fw.flush();
					fw.close();
				} catch (IOException e) {
					System.out.println("Flushing/closing error!");
					e.printStackTrace();
				}
			}
	        
	    }
        return hr;
    }
    // result of searching by room type
    public List<HotelRoom> getRoomListByType(String type)
    {
    	HotelRoom hr = null;
        List<HotelRoom> AllRoom = null;
        List<HotelRoom> AllRoomWithFilter = new ArrayList<HotelRoom>();
        RoomDB ctrl =new RoomDB();
        try {
        	AllRoom = ctrl.getAllRooms();
        } catch (IOException ex) {
            Logger.getLogger(HotelRoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
            //System.out.print(AllUser.size());
        /*System.out.println("before removing----");
        for(HotelUser user: AllUser) {
            System.out.println(user);  // Will invoke overrided `toString()` method
        }
        */
        for (int i = 0; i< AllRoom.size();i++)
        {
            if (AllRoom.get(i).getType().equalsIgnoreCase(type))
            {
            	
            	HotelRoom hus = new HotelRoom(AllRoom.get(i).getId(),AllRoom.get(i).getRoomNumber(),AllRoom.get(i).getDailyRate(),AllRoom.get(i).getType(),AllRoom.get(i).getDescription(),AllRoom.get(i).getPrice(),AllRoom.get(i).getQuality(),AllRoom.get(i).getBeds(),AllRoom.get(i).getStatus(),AllRoom.get(i).isAvailable());
            	AllRoomWithFilter.add(hus);
            }
        }
        /*
        System.out.println("after removing----");
        for(HotelUser user: AllUser) {
            System.out.println(user);  // Will invoke overrided `toString()` method
        }
        */
        
        return AllRoomWithFilter;
    }
    
 // result of searching by room price
    public List<HotelRoom> getRoomListByPrice(String price)
    {
    	HotelRoom hr = null;
        List<HotelRoom> AllRoom = null;
        List<HotelRoom> AllRoomWithFilter = new ArrayList<HotelRoom>();
        RoomDB ctrl =new RoomDB();
        try {
        	AllRoom = ctrl.getAllRooms();
        } catch (IOException ex) {
            Logger.getLogger(HotelRoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
            //System.out.print(AllUser.size());
        /*System.out.println("before removing----");
        for(HotelUser user: AllUser) {
            System.out.println(user);  // Will invoke overrided `toString()` method
        }
        */
        for (int i = 0; i< AllRoom.size();i++)
        {
            if (AllRoom.get(i).getPrice() >= Integer.parseInt(price))
            {
            	
            	HotelRoom hus = new HotelRoom(AllRoom.get(i).getId(),AllRoom.get(i).getRoomNumber(),AllRoom.get(i).getDailyRate(),AllRoom.get(i).getType(),AllRoom.get(i).getDescription(),AllRoom.get(i).getPrice(),AllRoom.get(i).getQuality(),AllRoom.get(i).getBeds(),AllRoom.get(i).getStatus(),AllRoom.get(i).isAvailable());
            	AllRoomWithFilter.add(hus);
            }
        }
        /*
        System.out.println("after removing----");
        for(HotelUser user: AllUser) {
            System.out.println(user);  // Will invoke overrided `toString()` method
        }
        */
        
        return AllRoomWithFilter;
    }
    
    //Cancel reservation
	   // num wise object search and write, checks whether the reservation started or not
    // if started send string msg to caller method - cancelReservation of the HotelReservationController class
    
    public String cancelReservationLine(int reservationNum, Date dateToday)
    {
        HotelReservation hr = null;
        List<HotelReservation> Allreservation = null;
        RoomDB ctrl =new RoomDB();
        String msg = null;
        DateFormat df = new SimpleDateFormat("MM/dd/yyyy"); 
        Calendar c = Calendar.getInstance();
        c.setTime(dateToday);
        c.add(Calendar.DATE, 1);
        Date dayAfterToday = c.getTime();
        //String minusDate = df.format(c.getTime());
        //System.out.println("Date, with the default formattingiiiiiiiiiiiii: " + minusDate);
        try {
        	Allreservation = ctrl.getAllReservation();
        } catch (IOException ex) {
            Logger.getLogger(HotelUserController.class.getName()).log(Level.SEVERE, null, ex);
        }
            //System.out.print(AllUser.size());
        /*System.out.println("before removing----");
        for(HotelUser user: AllUser) {
            System.out.println(user);  // Will invoke overrided `toString()` method
        }
        */
        for (int i = 0; i< Allreservation.size();i++)
        {
            if (Allreservation.get(i).getReservationId() == reservationNum)
            {
            	if (Allreservation.get(i).getFromDate().equals(dayAfterToday))
            	{
                    hr = Allreservation.get(i);
                    //System.out.println("print id of: "+name + ha.getAdmin_id()+"\n");
                    Allreservation.remove(i);
            		msg = "CANCANCELWITHCOST";
            	}
            	else if (Allreservation.get(i).getFromDate().equals(dateToday))
            	{
            		msg = "CANNOTCANCEL";
            	}
            	else if (Allreservation.get(i).getToDate().equals(dateToday))
            	{
            		msg = "CANNOTCANCEL";
            	}
            	else if ((Allreservation.get(i).getFromDate().before(dateToday)) && (Allreservation.get(i).getToDate().after(dateToday)))
            	{
            		msg = "CANNOTCANCEL";
            	}
            	else {
	                hr = Allreservation.get(i);
	                //System.out.println("print id of: "+name + ha.getAdmin_id()+"\n");
	                Allreservation.remove(i);
	                msg = "INSERTED";
            	}
            }
            else
            	msg = "WRONGRESERVATIONID";
        }
        /*
        System.out.println("after removing----");
        for(HotelUser user: AllUser) {
            System.out.println(user);  // Will invoke overrided `toString()` method
        }
        */
        if (hr!= null)
	       {
			   FileWriter fw = null;
				
			   BufferedWriter bw = null;
			   try{
				   //String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\firstTestJava"+"\\"+"ohrUser.csv";
			        fw = new FileWriter(new File(userDbPathR),false);
			        bw = new BufferedWriter(fw);
		
			        fw.write(CSV_HEADER_RESERVATION);
			        fw.write('\n');
		
				for (HotelReservation hrv: Allreservation) {
					fw.write(String.valueOf(hrv.getId()));
					fw.write(',');
					fw.write(String.valueOf(hrv.getReservationId()));
					fw.write(',');
					fw.write(String.valueOf(hrv.getRoomId()));
					fw.write(',');
					fw.write(df.format(hrv.getFromDate()));
					fw.write(',');
					fw.write(df.format(hrv.getToDate()));
					fw.write('\n');
				}
		
				//System.out.println("Write CSV successfully!");
			} catch (Exception e) {
				hr = null;
				msg = "ERROR";
				System.out.println("Writing CSV error!");
				e.printStackTrace();
			} finally {
				try {
					fw.flush();
					fw.close();
				} catch (IOException e) {
					System.out.println("Flushing/closing error!");
					e.printStackTrace();
				}
			}
	        
	    }
        return msg;
    }
    
    // check reservation number and return room num for modification of reservation
    public String getRoomNumByReservationNum (int reservationNum)
    {
    	String msg = null;
    	
        int roomNum = 0;
        List<HotelReservation> Allreservation = null;
        RoomDB ctrl =new RoomDB();
        //System.out.println("reservationNum: "+reservationNum+"\n");
        try {
        	Allreservation = ctrl.getAllReservation();
        } catch (IOException ex) {
            Logger.getLogger(HotelReservationController.class.getName()).log(Level.SEVERE, null, ex);
        }
        for (int i = 0; i< Allreservation.size();i++)
        {	//System.out.println("print id of: "+Allreservation.get(i).getReservationId()+"\n");
        	//System.out.println(Allreservation.get(i).getReservationId() == reservationNum);
        	//boolean flag = Allreservation.get(i).getReservationId() == reservationNum;
            if (Allreservation.get(i).getReservationId() == reservationNum) 
            {
                roomNum = Allreservation.get(i).getRoomId();
                
                msg = String.valueOf(roomNum);
                break;
            }
            else
            {
            	msg = "NODATAFOUND";
            }
        }
    	return msg;
    }
    //get line num by reservation num
    public String getLineNumByReservationNum (int reservationNum)
    {
    	String msg = null;
    	
        int lineNum = 0;
        List<HotelReservation> Allreservation = null;
        RoomDB ctrl =new RoomDB();
        try {
        	Allreservation = ctrl.getAllReservation();
        } catch (IOException ex) {
            Logger.getLogger(HotelReservationController.class.getName()).log(Level.SEVERE, null, ex);
        }
        for (int i = 0; i< Allreservation.size();i++)
        {
            if (Allreservation.get(i).getReservationId() == reservationNum) 
            {
                lineNum = Allreservation.get(i).getId();
                //System.out.println("print id of: "+name + ha.getAdmin_id()+"\n");
                msg = String.valueOf(lineNum);
                break;
            }
            else
            {
            	msg = "NODATAFOUND";
            }
        }
    	return msg;
    }
    
    
    // get room type by room num
    public String getRoomTypeByRoomNum(int roomNum)
    {
    	String msg = null;
    	
        String roomType = null;
        List<HotelRoom> Allrooms = null;
        RoomDB ctrl =new RoomDB();
        try {
        	Allrooms = ctrl.getAllRooms();
        } catch (IOException ex) {
            Logger.getLogger(HotelRoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
        for (int i = 0; i< Allrooms.size();i++)
        {
            if (Allrooms.get(i).getRoomNumber() == roomNum) 
            {
            	roomType = Allrooms.get(i).getType();
                //System.out.println("print id of: "+name + ha.getAdmin_id()+"\n");
                msg = roomType;
            }
        }
        return msg;
    	
    }
    // check if reservation started?
    public String checkIfReservationStarted(int reservationNum, Date dateToday1)
    {
        HotelReservation hr = null;
        List<HotelReservation> Allreservation = null;
        RoomDB ctrl =new RoomDB();
        String msg = null;
        Date dateToday = null;
        SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");  
        try {
			dateToday = formatter.parse(formatter.format(dateToday1));
			//System.out.println(Allreservation.get(i).getToDate().equals(dateToday));
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
        	Allreservation = ctrl.getAllReservation();
        } catch (IOException ex) {
            Logger.getLogger(HotelUserController.class.getName()).log(Level.SEVERE, null, ex);
        }

        for (int i = 0; i< Allreservation.size();i++)
        {
            if (Allreservation.get(i).getReservationId() == reservationNum)
            {
            	
            	if (Allreservation.get(i).getFromDate().equals(dateToday))
            	{
            		msg = "CANNOTMODIFY";
            	}
            	else if (Allreservation.get(i).getToDate().equals(dateToday))
            	{
            		
            		msg = "CANNOTMODIFY";
            	}
            	else if ((Allreservation.get(i).getFromDate().before(dateToday)) && (Allreservation.get(i).getToDate().after(dateToday)))
            	{
            		msg = "CANNOTMODIFY";
            	}
            	else if((Allreservation.get(i).getFromDate().before(dateToday)) && (Allreservation.get(i).getToDate().before(dateToday)))
            	{
            		msg = "CANNOTMODIFY";
            	}
            	else {
	                msg = "CANMODIFY";
            	}

            }
       
        }
        //System.out.println(msg);
        return msg;
    }
    // this method is responsible for modify a reservation, checks if the reservation started or not, if
    // started one can not modify that reservation. if no room available for the reservation according
    // tho date range then search for other room of the same type, and if find reserve it.
	public String modifyReservation(List<Integer> roomlist, int reservationNum, int lineNum, Date fromDate, Date toDate) {
		HotelReservation hrev = null;
        List<HotelReservation> AllReservation = null;
        RoomDB ctrl =new RoomDB();
        int flag =0;
        int minRoomNum = 0;
        String msg = null;
		FileWriter fw = null;
		
		BufferedWriter bw = null;
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy"); 
		Date getFromDate = null;
		Date getToDate = null;
		HotelReservationController hrc = new HotelReservationController();
        // Clone the list
        List<Integer> cloned_list_roomlist = new ArrayList<Integer>(roomlist);
        List<HotelReservation> clonedAllReservation = null;
       // System.out.println("ArrayList contains cloned_list_roomlist: " + cloned_list_roomlist);

        try {
        	AllReservation = ctrl.getAllReservation();
            // Clone the list
            clonedAllReservation = new ArrayList<HotelReservation>(AllReservation);
            
        } catch (IOException ex) {
            Logger.getLogger(HotelRoomController.class.getName()).log(Level.SEVERE, null, ex);
        }
		
        for (int x = 0; x< clonedAllReservation.size();x++)
        {
            if (clonedAllReservation.get(x).getReservationId() == reservationNum)
            {
            	hrev = clonedAllReservation.get(x);
            	getFromDate = clonedAllReservation.get(x).getFromDate();
            	getToDate = clonedAllReservation.get(x).getToDate();
                //System.out.println("print id of: "+name + ha.getAdmin_id()+"\n");
            	clonedAllReservation.remove(x);
        		
            }
        }
		for (int j = 0; j< roomlist.size();j++)
		{
			//System.out.println("room list size :"+roomlist.size());
			for (int i = 0; i< clonedAllReservation.size();i++)
			{
				if(clonedAllReservation.get(i).getRoomId() == roomlist.get(j))
				{
					//System.out.println("room num count now :"+roomlist.get(j));
					if((clonedAllReservation.get(i).getFromDate().equals(fromDate)) && (clonedAllReservation.get(i).getToDate().equals(toDate)))
					{
						flag = flag+1;
						cloned_list_roomlist.remove(roomlist.get(j));
						break;
					}
					else if(clonedAllReservation.get(i).getFromDate().equals(fromDate))
					{
						cloned_list_roomlist.remove(roomlist.get(j));
						break;
					}
					else if(clonedAllReservation.get(i).getFromDate().equals(toDate))
					{	//System.out.println("todate> ");
						cloned_list_roomlist.remove(roomlist.get(j));
						break;
					}
					else if(clonedAllReservation.get(i).getToDate().equals(toDate))
					{
						cloned_list_roomlist.remove(roomlist.get(j));
						break;
					}
					else if(clonedAllReservation.get(i).getToDate().equals(fromDate))
					{    
						cloned_list_roomlist.remove(roomlist.get(j));
						break;
					}
					else if ((clonedAllReservation.get(i).getFromDate().after(fromDate))&&(clonedAllReservation.get(i).getToDate().after(toDate)))
					{
						flag = flag+1;
						cloned_list_roomlist.remove(roomlist.get(j));
						break;
					}
					else if((clonedAllReservation.get(i).getFromDate().before(fromDate))&&(clonedAllReservation.get(i).getToDate().after(toDate)))
					{
						flag = flag+1;
						cloned_list_roomlist.remove(roomlist.get(j));
						break;
					}
					else if(clonedAllReservation.get(i).getFromDate().before(fromDate)&&(clonedAllReservation.get(i).getToDate().before(toDate)))
					{
						flag = flag+1;
						cloned_list_roomlist.remove(roomlist.get(j));
						break;
					}
					
				}
			}

		}
		
		if(cloned_list_roomlist.size()>0)
		{
		//System.out.println("ArrayList contains : " + cloned_list_roomlist);
		   minRoomNum = Collections.min(cloned_list_roomlist);
		   //System.out.println("Minimum element : " + Collections.min(cloned_list_roomlist));
		   
		   //--------------------------------

		   try{
			   //String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\firstTestJava"+"\\"+"ohrUser.csv";
		        fw = new FileWriter(new File(userDbPathR),false);
		        bw = new BufferedWriter(fw);
	
		        fw.write(CSV_HEADER_RESERVATION);
		        fw.write('\n');
	
			for (HotelReservation hrv: clonedAllReservation) {
				fw.write(String.valueOf(hrv.getId()));
				fw.write(',');
				fw.write(String.valueOf(hrv.getReservationId()));
				fw.write(',');
				fw.write(String.valueOf(hrv.getRoomId()));
				fw.write(',');
				fw.write(df.format(hrv.getFromDate()));
				fw.write(',');
				fw.write(df.format(hrv.getToDate()));
				fw.write('\n');
			}
	
			//System.out.println("Write CSV successfully!");
		} catch (Exception e) {
			hrev = null;
			msg = "ERROR";
			System.out.println("Writing CSV error!");
			e.printStackTrace();
		} finally {
			try {
				fw.flush();
				fw.close();
			} catch (IOException e) {
				System.out.println("Flushing/closing error!");
				e.printStackTrace();
			}
		}
        
    
		   //--------------------------------------------
		   hrev = new HotelReservation(lineNum, reservationNum, minRoomNum, fromDate, toDate);
		   try{
			   //String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrCustomer.csv";
		        fw = new FileWriter(new File(userDbPathR),true);
		        bw = new BufferedWriter(fw);
		
		        
				bw.append(String.valueOf(lineNum));
				bw.append(',');
				bw.append(String.valueOf(reservationNum));
				bw.append(',');
				bw.append(String.valueOf(hrev.getRoomId()));
				bw.append(',');
				bw.append(df.format(hrev.getFromDate()));
				bw.append(',');
				bw.append(df.format(hrev.getToDate()));
		
				bw.append('\n');
				bw.close();
		
				msg = "MODIFIED";
				
			//System.out.println("Write CSV successfully!");
		} catch (Exception e) {
			msg = "ERROR;";
			System.out.println("Writing CSV error!");
			e.printStackTrace();
		} 
		   finally {
	           if(bw != null) {
	                try {
						bw.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	            }
	            if(fw != null) {
	                try {
						fw.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
	            }
		   }
		}
		else
		{
			msg = "NOROOMAVAILABLE";
		}
		return msg;
	}
}
