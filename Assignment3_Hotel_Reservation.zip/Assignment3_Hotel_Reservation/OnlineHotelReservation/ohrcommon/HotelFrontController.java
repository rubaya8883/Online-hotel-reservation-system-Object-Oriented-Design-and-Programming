/**
 * 
 */
package ohrcommon;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * The FrontController Class is the initial contact point for handling requests for Admin/Customer
 * view. It checks Authentication.
 * @author Rubaya
 *
 */
public class HotelFrontController 
{
	private HotelDispatcher dispatcher;
	public IOperations op;
	public boolean checkAuthentication;
	// for command pattern-
	MessageCommandInvoker msgComdInv=new MessageCommandInvoker();
	MessageReceiver msgRecevr=new MessageReceiver();
	MessageCommand adminMsgComnd=new AdminMessageCommand(msgRecevr);
	MessageCommand custMsgComnd=new CustomerMessageCommand(msgRecevr);
	
	public HotelFrontController(){
		dispatcher = new HotelDispatcher();
	   }
	
//this method is calling by the HotelClient class for connection to hotel server
	public void connectToHotel(String host, int port) throws RemoteException{
		try{
			
			//for local host
			/*
			String name="//"+host+":"+port+"/Online_hotel";
			Registry registry = LocateRegistry.getRegistry(host,port);
			op = (IOperations)registry.lookup(name);
			*/
			//for tesla
			
			String name="//"+host+":"+port+"/Online_hotel";
			op = (IOperations)Naming.lookup(name);
			//end tesla
			
			System.out.println("Found server object from client");
		}catch(Exception ex){
			System.out.println("Client error :" + ex.getMessage());
			ex.printStackTrace();
		}
		
	}
	// customer registration method to register new customer by a customer
	public void customerRegistrationByCustomer()
	{
        RegisterCustomerView rcv = new RegisterCustomerView();

        String[] dataForCus = rcv.View();
        HotelUser husForCus = null;
        String msgAddCustomer;
        String msgAddUser;
        try {
			msgAddCustomer = op.addCustomer(new HotelCustomer(0, 0, dataForCus[0], dataForCus[4], dataForCus[5], dataForCus[6]));
			msgAddUser = op.registerCustomer(new HotelUser(0, dataForCus[0], dataForCus[3], dataForCus[1], dataForCus[2]));
			rcv.showMessage(msgAddCustomer);
			rcv.showMessage(msgAddUser);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        //System.out.print("Successfully Registered(NOT SAVED IN DATABASE YET) inside fc\n"); 
	}
	
	// admin registration by admin (calling from admin home)
	public void addAdminByAdmin()
	{
        //RegisterAdminView rav = new RegisterAdminView();
		//Abstract factory pattern
		AbstractViewFactory viewFactory = ViewFactoryProducer.getFactory("ADMINFactory");
		ViewInterface viewObj = viewFactory.getViewInstance("ADDADMIN");
		
        String[] dataAdmin = viewObj.View();
        HotelUser husa = null;
        String msgAddAdmin;
        String msgAddUser;
		//for (int i = 0; i < dataAdmin.length; i++) {
		//System.out.println(dataAdmin[i]);
		//}
        try {
        	msgAddAdmin = op.addAdmin(new HotelAdmin(0, 0, dataAdmin[0], dataAdmin[4], dataAdmin[5], dataAdmin[6]));
        	msgAddUser = op.registerAdmin(new HotelUser(0, dataAdmin[0], dataAdmin[3], dataAdmin[1],dataAdmin[2]));
        	viewObj.showMessage(msgAddAdmin);
        	viewObj.showMessage(msgAddUser);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
        //System.out.print("Successfully Registered Admin(NOT SAVED IN DB YET) inside fc\n"); 

	}
	// admin adding customer (calling from admin home)
	public void addCustomerByAdmin()
	{
		//RegisterCustomerView rcva = new RegisterCustomerView();
		//Abstract factory pattern
		AbstractViewFactory viewFactory = ViewFactoryProducer.getFactory("ADMINFactory");
		ViewInterface viewObj = viewFactory.getViewInstance("ADDCUSTOMER");
		
        String[] dataForcusA = viewObj.View();
        HotelUser husForcusA = null;
        String msgAddCustomer;
        String msgAddUser;
        try {
			msgAddCustomer = op.addCustomer(new HotelCustomer(0, 0, dataForcusA[0], dataForcusA[4], dataForcusA[5], dataForcusA[6]));
			msgAddUser = op.registerCustomer(new HotelUser(0, dataForcusA[0], dataForcusA[3], dataForcusA[1], dataForcusA[2]));
        	viewObj.showMessage(msgAddCustomer);
        	viewObj.showMessage(msgAddUser);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        //System.out.print("Successfully Registered the customer by the admin(NOT SAVED IN DB YET) inside fc\n"); 
	}
	// remove customer by admin (calling from admin home)
	public void removeCustomerByAdmin()
	{
		//RemoveCustomerView rcv = new RemoveCustomerView();
		//Abstract factory pattern
		AbstractViewFactory viewFactory = ViewFactoryProducer.getFactory("ADMINFactory");
		ViewInterface viewObj = viewFactory.getViewInstance("REMOVCUSTOMER");
		
		String[] dataForRemvCust = viewObj.View();
        String msgRmCustomer;
        String msgRmCus;
        String msg;
		if(dataForRemvCust[0] == null && dataForRemvCust[1] == null && dataForRemvCust[2] == null) {
			msg = "You have not entered all information.";
			viewObj.showMessage(msg);
        }
		else
		{
	    	try {
	    		msgRmCustomer = op.deleteCustomer(dataForRemvCust[0], dataForRemvCust[1], dataForRemvCust[2]);
	    		msgRmCus = op.deleteCustomerUser(dataForRemvCust[0], dataForRemvCust[1]);
	    		
	    		viewObj.showMessage(msgRmCustomer);
	        
	        	viewObj.showMessage(msgRmCus);
	        	
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//System.out.println("Successfully remove the Customer by the admin(NOT SAVED IN DB YET)\\n");
	}
	// remove admin by admin (calling from admin home)
	public void removeAdminByAdmin()
	{
		//RemoveAdminView rav = new RemoveAdminView();
		//Abstract factory pattern
		AbstractViewFactory viewFactory = ViewFactoryProducer.getFactory("ADMINFactory");
		ViewInterface viewObj = viewFactory.getViewInstance("REMOVADMIN");
		
		String[] dataForRemvAdmin = viewObj.View();
		//String dataForRmAdmin = dataForRemvAdmin[0];
        //HotelUser husForAdmin = null;
        String msgRmAdmin;
        String msgRmUser;
        String msg;
        // check if no data input given
		if(dataForRemvAdmin[0] == null && dataForRemvAdmin[1] == null && dataForRemvAdmin[2] == null) {
			msg = "You have not entered all information.";
			viewObj.showMessage(msg);
        }
		else
		{
	        try {
	        	
	        	msgRmAdmin = op.deleteAdmin(dataForRemvAdmin[0], dataForRemvAdmin[1], dataForRemvAdmin[2]);
	        	msgRmUser = op.deleteAdminUser(dataForRemvAdmin[0], dataForRemvAdmin[1]);
	        	// calling method showMessage for showing message
	        	viewObj.showMessage(msgRmAdmin);
	        	viewObj.showMessage(msgRmUser);
	        	
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//System.out.println("Successfully remove the Admin by the admin(NOT SAVED IN DB YET)\\n");
	}
	// update hotel room by customer (calling from admin home)
	public void updateHotelRoomByAdmin()
	{
		//UpdateRoomView urv = new UpdateRoomView();
		//Abstract factory pattern
		AbstractViewFactory viewFactory = ViewFactoryProducer.getFactory("ADMINFactory");
		ViewInterface viewObj = viewFactory.getViewInstance("UPDATEROOM");
		
		String[] dataForRoomUpdate = viewObj.View();
		String msg;
		//for (int i = 0; i < dataForRoomUpdate.length; i++) {
			//System.out.println(dataForRoomUpdate[i]);
			//}
		if(dataForRoomUpdate[0] == null && dataForRoomUpdate[1] == null && dataForRoomUpdate[2] == null) {
			msg = "You have not selected any update option.";
			viewObj.showMessage(msg);
        }
		else {
			try {
				msg = op.updateHotelRoom(dataForRoomUpdate[0], dataForRoomUpdate[1], dataForRoomUpdate[2]);
				viewObj.showMessage(msg);
				
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
	}
	// customer activities--
	// customer browses room using two options (calling from customer home)
	public void browseHotelRoomByCustomer()
	{
        //HotelRoomBrowserView hrbv = new HotelRoomBrowserView();
		//Abstract factory pattern
		AbstractViewFactory viewFactory = ViewFactoryProducer.getFactory("CUSTOMERFactory");
		ViewInterface viewObj = viewFactory.getViewInstance("ROOMBROWSER");
		// creating object of roomView to showing list of rooms according to search criteria
		RoomView objRoomView = new RoomView();
		
        String [] dataHrbv = viewObj.View();
        
		//for (int i = 0; i < dataHrbv.length; i++) {
		//System.out.println(dataHrbv[i]);
		//}
        String msg;
		if(dataHrbv[0] == null && dataHrbv[1] == null) {
			msg = "You have not selected any browsing option.";	
			viewObj.showMessage(msg);
        }
		else{
		
			try {
				List<HotelRoom> rooms = op.browseHotelRooms(dataHrbv[0], dataHrbv[1]);
				if(rooms.size() == 0)
				{
					msg = "No room has been found according to the search criteria, Please search again";
					viewObj.showMessage(msg);
				}
				else
				{
					msg = "Rooms are available according to the search criteria.";
					viewObj.showMessage(msg);
					objRoomView.showRoomList(rooms);
					
				}
				//will create another view to show this.
				//viewObj.showRoomList(rooms);
			} catch (RemoteException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//System.out.print("\nRooms are available for booking!!\n");
			}
	}
	

	// making reservation by customer
	public void makeRoomReservationByCustomer()
	{
		//HotelReservationView hrv = new HotelReservationView();
		//Abstract factory pattern
		AbstractViewFactory viewFactory = ViewFactoryProducer.getFactory("CUSTOMERFactory");
		ViewInterface viewObj = viewFactory.getViewInstance("RESERVATION");
		
        String [] roomResvData = viewObj.View();
        String msgForReservation;
        DateFormat df = new SimpleDateFormat("MM/dd/yyyy"); 
        Date frmDatet = null;
        Date toDatet = null;
		if(roomResvData[0] == null && roomResvData[1] == null && roomResvData[2] == null) {
			msgForReservation = "You have not entered all information.";
			viewObj.showMessage(msgForReservation);
        }
		else {
	        try {
	        	// check date conversion ( as the input formate is okay or not and also convert string to date)
	        	frmDatet = df.parse(roomResvData[0]);
	        	toDatet = df.parse(roomResvData[1]);
		        try {
		        	msgForReservation = op.placeReservation(frmDatet, toDatet, roomResvData[2]);
		        	viewObj.showMessage(msgForReservation);
				} catch (RemoteException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				msgForReservation = "You have entered wrong date format, please try again.";
				viewObj.showMessage(msgForReservation);
				e.printStackTrace();
			}
		

	        //System.out.print("\n You have successfully made a reservation!!\n");
		}
	}
	// this method is for cancel reservation by customer (calling from admin home)
	public void cancelRoomReservationByCustomer()
	{
		//CancelReservationView crv = new CancelReservationView();
		//Abstract factory pattern
		
		AbstractViewFactory viewFactory = ViewFactoryProducer.getFactory("CUSTOMERFactory");
		ViewInterface viewObj = viewFactory.getViewInstance("CANCELRESERV");
		
        String [] roomCancelResvData = viewObj.View();
        
		//for (int i = 0; i < roomCancelResvData.length; i++) {
		//System.out.println(roomCancelResvData[i]);
		//}
        String msgForCancelReservation;
        int reservationNum;
        String stringDateToday = roomCancelResvData[1];
        DateFormat df = new SimpleDateFormat("MM/dd/yyyy"); 
        Date dateToday = null;
        
        //Date minusDate = null;
		try {
			dateToday = df.parse(stringDateToday);
			//System.out.println("Date2 is before date1: " + dateToday.toString());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        
		if(roomCancelResvData[0] == null && roomCancelResvData[1] == null) {
			msgForCancelReservation = "You have not entered reservation number.";	
			viewObj.showMessage(msgForCancelReservation);
        }
		else
		{
			if (!roomCancelResvData[0].isEmpty())
			{
		        String str = roomCancelResvData[0];
		        try{
		            reservationNum = Integer.parseInt(str);
		            //System.out.println(reservationNum); // output = 25
					try {
						msgForCancelReservation = op.cancelReservation(reservationNum, dateToday);
						viewObj.showMessage(msgForCancelReservation);
					} catch (RemoteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		        }
		        catch (NumberFormatException ex){
		        	msgForCancelReservation = "Wrong Reservation Id. Please enter all degits.";
		        	viewObj.showMessage(msgForCancelReservation);
		            ex.printStackTrace();
		        }
			}
			
		}
        //System.out.print("\nReservation is successfully cancelled; You may need to pay\n");
	}
	// for reservation modification
	public void modifyRoomReservationByCustomer()
	{
		//ModifyReservationView mrv = new ModifyReservationView();
		//Abstract factory pattern
		AbstractViewFactory viewFactory = ViewFactoryProducer.getFactory("CUSTOMERFactory");
		ViewInterface viewObj = viewFactory.getViewInstance("MODIFYRESERV");
		
        String [] modifyResvData = viewObj.View();
        String msgForModifyReservation;
        int reservationNum;
        DateFormat df = new SimpleDateFormat("MM/dd/yyyy"); 
        Date frmDatet = null;
        Date toDatet = null;
		if(modifyResvData[0] == null && modifyResvData[1] == null && modifyResvData[2] == null) {
			msgForModifyReservation = "You have not entered all information.";	
			viewObj.showMessage(msgForModifyReservation);
        }
		else
		{

	        try {
	        	frmDatet = df.parse(modifyResvData[0]);
	        	toDatet = df.parse(modifyResvData[1]);
		        String str = modifyResvData[2];
		        try{
		            reservationNum = Integer.parseInt(str);
			        try {
			        	msgForModifyReservation = op.modifyReservation(frmDatet, toDatet, reservationNum);
			        	viewObj.showMessage(msgForModifyReservation);
					} catch (RemoteException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		        }
		        catch (NumberFormatException ex){
		        	msgForModifyReservation = "Wrong Reservation Id. Please enter all degits.";
		        	viewObj.showMessage(msgForModifyReservation);
		            ex.printStackTrace();
		        }
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				msgForModifyReservation = "You have entered wrong date format, please try again.";	
				viewObj.showMessage(msgForModifyReservation);
				e.printStackTrace();
			}
		
		}
	}
	
	private boolean isAuthenticUser(){
		if (checkAuthentication) {
			return true;
		}
		else {
			
			return false;
		}
	   }
	// user authentication check 
	public boolean authenticateUser(String username, String password) throws RemoteException {
		//System.out.println("check authenticate.");
        HotelUser hus1 = null;
		try {
			hus1 = op.login(username,password);
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        if (hus1 == null)
        {
            System.out.print("Login unsuccessful\n");
            checkAuthentication = false;
            return checkAuthentication;
        }
        else
        {
        	checkAuthentication = true;
        	if(hus1.getRole().equals("A"))
        	{	
        		// command pattern
        		msgComdInv.setMsgCommand(adminMsgComnd);
        		msgComdInv.invokeCommand(username);
        		dispatchRequest("ADMIN");
        		//System.out.println("You entered operSelection for admin: " + operSelection);
        		
        	}
        	else {
        		// command pattern
        			msgComdInv.setMsgCommand(custMsgComnd);
        			msgComdInv.invokeCommand(username);
					dispatchRequest("CUSTOMER");
					//System.out.println("You entered operSelection for customer: " + operSelection);

        		}
        	return checkAuthentication;
        }
		
	}
	
	private void trackRequest(String request){
	   System.out.println("Page requested: " + request);
	   }

	public void dispatchRequest(String request)
	{
	   //log each request
	   
	   trackRequest(request);
	      
	   //authenticate the user
	   if(isAuthenticUser()){
		   dispatcher.dispatch(request, (HotelFrontController)this);
		   //return opselection;
	   }
	   //return opselection;	
	}
}
