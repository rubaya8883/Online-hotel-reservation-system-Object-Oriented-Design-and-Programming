/**
 * 
 */
package ohrcommon;

import java.util.Scanner;

/**
 * demo view of customer registration.
 * @author Rubaya
 *
 */
public class RegisterCustomerView implements ViewInterface{
	//concrete class
	@Override
	public String[] View()
    {
		System.out.println("----------------- Register Customer----------------------- ");
        String[] customerData = new String[7];
        System.out.print("Enter your name\n");
        
        Scanner scann = new Scanner(System.in);
        customerData[0] = scann.nextLine();
        System.out.print("Enter your username\n");
        customerData[1] = scann.nextLine();
        System.out.print("Enter Password:\n");
        customerData[2] = scann.nextLine();
        customerData[3] = "C";
        System.out.print("Enter Credit card:\n");
        customerData[4] = scann.nextLine();
        System.out.print("Enter Address:\n");
        customerData[5] = scann.nextLine();
        System.out.print("Enter Cellphone:\n");
        customerData[6] = scann.nextLine();
        System.out.println("---------------------------------------------------------");
        return customerData;
    }

	@Override
	public void showMessage(String msg) {
		// TODO Auto-generated method stub
		System.out.println(msg + "\n");
		
	}
}
