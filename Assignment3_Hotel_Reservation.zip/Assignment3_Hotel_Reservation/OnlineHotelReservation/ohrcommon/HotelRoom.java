/**
 * 
 */
package ohrcommon;

/**
 * Hotel HotelRoom object (model object).
 * @author Rubaya
 *
 */
public class HotelRoom implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    private int id;
    private int roomNumber;
    private int dailyRate;
    private String type;
    private String description;
    private int price;
    private int quality;
    private int beds;
    private String status;
    private String isAvailable;

    @Override
	public String toString() {
    	return "HotelRoom [Room Number=" + roomNumber + ", Daily Rate=" + dailyRate + ", Type=" + type
				+ ", Description=" + description + ", Price=" + price + ", Quality=" + quality + ", Number of Beds=" + beds
				+ ", Status=" + status + ", Available today?=" + isAvailable + "]";
	}

	public HotelRoom(int id,int roomNumber, int dailyRate, String type, String description, int price, int quality, int beds, String status, String isAvailable)
    {
        this.setId(id);
        this.setRoomNumber(roomNumber);
        this.setDailyRate(dailyRate);
        this.setType(type);
        this.setDescription(description);
        this.setPrice(price);
        
        this.setQuality(quality);
        this.setBeds(beds);
        this.setStatus(status);
        this.setAvailable(isAvailable);
        
        
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}

	public int getDailyRate() {
		return dailyRate;
	}

	public void setDailyRate(int dailyRate) {
		this.dailyRate = dailyRate;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getQuality() {
		return quality;
	}

	public void setQuality(int quality) {
		this.quality = quality;
	}

	public int getBeds() {
		return beds;
	}

	public void setBeds(int beds) {
		this.beds = beds;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String isAvailable() {
		return isAvailable;
	}

	public void setAvailable(String isAvailable2) {
		this.isAvailable = isAvailable2;
	}


}
