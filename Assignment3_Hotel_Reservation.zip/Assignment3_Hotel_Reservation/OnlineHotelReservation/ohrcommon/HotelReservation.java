/**
 * 
 */
package ohrcommon;

import java.util.Date;

/**
 * Hotel HotelReservation object (model object). 
 * @author Rubaya
 *
 */
public class HotelReservation {
	private int id;
	private int reservationId;
	private int roomId;
	private Date fromDate;
	private Date toDate;
	//private String status;
    

	

	public HotelReservation(int id, int reservationId, int roomId, Date fromDate, Date toDate) 
    {
    		this.setId(id);
    		this.setReservationId(reservationId);
    		this.setRoomId(roomId);
            this.setFromDate(fromDate);
            this.setToDate(toDate);
            //this.setStatus(status); 
                    
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getReservationId() {
		return reservationId;
	}

	public void setReservationId(int reservationId) {
		this.reservationId = reservationId;
	}

	public int getRoomId() {
		return roomId;
	}

	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	/*public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	} */
}
