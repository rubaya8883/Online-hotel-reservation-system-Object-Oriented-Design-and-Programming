/**
 * 
 */
package ohrcommon;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *  Controller class for hotel Customer
 *  server side controller
 * @author Rubaya
 *
 */
public class HotelCustomerController implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    // this method is calling from IOperationImpl class, uses templete method
	public String addCustomer(HotelCustomer hcus)
    {
		String msg = null;
		String msg2 = null;
		int line;
		CsvConnectionTemplate customerDB = new CustomerDB();
		CustomerDB cusDB = new CustomerDB();
		msg = customerDB.csvConnection();
		if (msg.equals("FOUND"))
		{
			line = customerDB.getLineNum(); //this lineNum method is in CSvconnectionTemplete class
			msg2 = cusDB.addCustomerToCsv(hcus, line);
			return msg2;
		}
		else
			return msg;
		//System.out.print("Customer added successfully! The actual addition to database is yet to be implemented.\n");
    }
    // calling from IOperationImpl class, passes data to CustomerDB class. calls method cusrDB.getCustomer
	public String deleteHotelCustomer(String name, String cellphone)
	{
		String msg = null;
		boolean check;
		HotelCustomer hcus = null;
		CustomerDB cusrDB =new CustomerDB();
		check = cusrDB.getCsvFile();
		if(check)
		{
			hcus = cusrDB.getCustomer(name, cellphone);
			if (hcus == null)
			{
				msg = "NOTFOUND";
			}
			else
			{
				msg = "FOUND";
			}
		}
		else
		{
			msg = "FILENOTFOUND";
		}
		
		return msg;
		
	}
}
