/**
 * 
 */
package ohrcommon;

/**
 * @author Rubaya
 * Create an interface to get factories for AdminView and CustomerView Objects.
 *
 */
public interface AbstractViewFactory {
	public ViewInterface getViewInstance(String viewType);
}
