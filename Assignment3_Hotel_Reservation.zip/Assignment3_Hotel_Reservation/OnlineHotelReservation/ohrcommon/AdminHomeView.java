/**
 * 
 */
package ohrcommon;

import java.util.Scanner;

/**
 * View for admin home page after successful login.
 * @author Rubaya
 *
 */
public class AdminHomeView {
	public void showAdminHomeView(HotelFrontController hotelFrontController)
	{	boolean isExit = false;
		Integer operationA = null;
		while(!isExit)
		{
			//System.out.print("Your role is: admin\n");
			System.out.println("--------------- Admin Activities----------------------- ");
	
			System.out.println("1. Add a new Admin ");
			System.out.println("2. Add Customer Account");
			System.out.println("3. Remove Admin Account");
			System.out.println("4. Remove Customer Account");
			System.out.println("5. Update Hotel Room");
			System.out.print("6. Exit\n");
			//System.out.println("4. Exit\n");
			System.out.println("---------------End Admin Activities----------------------");
			System.out.println("Select an option to continue\n");
			Scanner scan1 = new Scanner(System.in);
			operationA = scan1.nextInt();
			if (operationA.equals(1)){
				hotelFrontController.addAdminByAdmin();
			}
			else if (operationA.equals(2)){
				hotelFrontController.addCustomerByAdmin();
			}
			else if(operationA.equals(3)){
				hotelFrontController.removeAdminByAdmin();
			}
			else if(operationA.equals(4)){
				hotelFrontController.removeCustomerByAdmin();
			}
			else if(operationA.equals(5)){
				hotelFrontController.updateHotelRoomByAdmin();
			}
			else if(operationA.equals(6)){
				isExit = true;
			}
			else {
				System.out.println("Invalid input.");
			}
		
		}
		
	}
}
