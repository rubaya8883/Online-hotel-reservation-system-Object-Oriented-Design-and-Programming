/**
 * 
 */
package ohrcommon;

/**
 * Hotel Admin object (model object). 
 * @author Rubaya
 *
 */
public class HotelAdmin implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	private int id;
	private int admin_id;
	private String name;
	private String zone;
	private String isPrimary;
	private String cellPhone;
	
    public HotelAdmin(int id, int admin_id, String name, String zone, String IsPrimary, String cellPhone)
    {
        this.setId(id);
        this.setAdmin_id(admin_id);
        this.setName(name);
        this.setZone(zone);
        this.setIsPrimary(IsPrimary);
        this.setCellPhone(cellPhone);
    }

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getAdmin_id() {
		return admin_id;
	}

	public void setAdmin_id(int admin_id) {
		this.admin_id = admin_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public String getIsPrimary() {
		return isPrimary;
	}

	public void setIsPrimary(String isPrimary) {
		this.isPrimary = isPrimary;
	}

	public String getCellPhone() {
		return cellPhone;
	}

	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}
	
    @Override
	public String toString() {
		return "HotelAdmin [id=" + id + ", admin_id=" + admin_id + ", name=" + name + ", zone=" + zone + ", isPrimary="
				+ isPrimary + ", cellPhone=" + cellPhone + "]";
	}
}
