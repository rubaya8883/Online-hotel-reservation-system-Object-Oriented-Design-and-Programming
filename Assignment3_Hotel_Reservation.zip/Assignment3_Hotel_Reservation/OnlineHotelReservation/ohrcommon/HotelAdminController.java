package ohrcommon;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Controller class for hotel Admin
 * @author Rubaya
 *
 */
public class HotelAdminController implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// this method is calling by IOperationImpl class, uses templete method,
	//passes data AdminDB class
	public String addHotelAdmin(HotelAdmin ha)
    {
		String msg = null;
		String msg2 = null;
		int line;
		CsvConnectionTemplate adminDB = new AdminDB();
		AdminDB adDB = new AdminDB();
		msg = adminDB.csvConnection();
		if (msg.equals("FOUND"))
		{
			line = adminDB.getLineNum();// this lineNum method is in CSvconnectionTemplete class
			msg2 = adDB.addAdminToCsv(ha, line);
			return msg2;
		}
		else
			return msg;
		
       
        //return msg;
    }
    // calling from IOperationImpl class passes and receives data from AdminDB class to delete admin
	// either name or cellphone num required to delete admin( any thing should be correct)
	public String deleteHotelAdmin(String name, String cellphone)
	{
		String msg = null;
		boolean check;
		HotelAdmin ha = null;
		AdminDB adDB = new AdminDB();
		check = adDB.getCsvFile();
		if(check)
		{
			ha = adDB.getAdmin(name, cellphone);
			if (ha == null)
			{
				msg = "NOTFOUND";
			}
			else
			{
				msg = "FOUND";
			}
		}
		else
		{
			msg = "FILENOTFOUND";
		}
		
		return msg;
		
	}
}
