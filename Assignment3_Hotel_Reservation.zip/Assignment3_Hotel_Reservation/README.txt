The submitted folder contains-
1) A README file
2) OnlineHotelReservation folder, which contains the project.
3) Inside the OnlineHotelReservation folder, there is a Makefile ( to clean and compile all codes in the package folders)
4) a report file as pdf
Please go through the "Description of the files" point from the report
for better understanding of the coding.

NOTE: I have tried to run the code in "in-csci-rpc" machines -
old.in-csci-rrpc02.cs.uni.edu
old.in-csci-rrpc03.cs.uni.edu
old.in-csci-rrpc04.cs.uni.edu
old.in-csci-rrpc05.cs.uni.edu
old.in-csci-rrpc06.cs.uni.edu

but, those machines are extremely slow. And showing connection timeout.
So, the instruction for running in the tesla machine has been given here
here host name: "localhost" and port:2403 (you can use any port name)

Commands needed to run the OnlineHotelReservation Example-

1.ssh username@tesla.cs.uni.edu

2.create a folder with any name ( for example- "oodp")
command - mkdir oodp

3. To change directory permissions-
chmod +rwx filename to add permissions. ( here filename -oodp )

4. copy the OnlineHotelReservation folder to the tesla machine inside the folder named oodp

5. cd oodp/OnlineHotelReservation/
6. Clean the class files

make clean
7. Compile all java files-

make


8. As I have faced problem with "in-csci-rpc machines" to execute code
I have run my code in tesla machine.
9. ps eaf | grep rmiregistry

10. Check the port id, which will be given to run, (eg. 2403 ).
if rmiregistry job is running, kill it : kill -9 <pid>
then 
rmiregistry 2403 & (run rmi registry withy any port num, for eg -2403)

11.To run the server- (any machine you can select as host name)
java ohrserver/HotelServer in-csci-rrpc01 <port-number>
---in step 11---------i have use this command below---------
for example-
I have run:
java ohrserver/HotelServer localhost 2403

For running the client-

12.(please open another terminal and run command)
ssh username@tesla.cs.uni.edu
due to problem with "in-csci-rpc machines". I have run my client code on same tesla machine

13. cd oodp/OnlineHotelReservation

14. java ohrclient/HotelClient in-csci-rrpc01 <port-number>
---in step 14---------i have use this command below---------
for example-
I have run:
java ohrclient/HotelClient localhost 2403

NOTE:
   It will give option to register as a customer and login (as admin or as customer). 
 username is "rubaya"
 and correct password is "rabab". 
Role will be shown as admin

 For customer username is "leo" and password is "leo123".
Or username: aj , password: aj123

----------------------If you want to run the code in any "in-csci-rpc machines" then follow these steps----------------

1.ssh username@tesla.cs.uni.edu

2.create a folder with any name ( for example- "oodp")
command - mkdir oodp

3. To change directory permissions-
chmod +rwx filename to add permissions. ( here filename -oodp )

4. copy the OnlineHotelReservation folder to the tesla machine inside the folder named oodp

5. Change the file permission using the command in step 3. then-
cd oodp/OnlineHotelReservation

6. Clean the class files

make clean

7. Compile all java files-

make

8. You can use the following machines for RMI :
old.in-csci-rrpc02.cs.uni.edu
old.in-csci-rrpc03.cs.uni.edu
old.in-csci-rrpc04.cs.uni.edu
old.in-csci-rrpc05.cs.uni.edu
old.in-csci-rrpc06.cs.uni.edu

For server running select any machine- (eg. login to in-csci-rrpc01.cs.uni.edu machine)
ssh old.in-csci-rrpc02.cs.uni.edu

9. cd oodp/OnlineHotelReservation

10. ps eaf | grep rmiregistry

11. Check the port id, which will be given to run, (eg. 2888 ).
if rmiregistry job is running, kill it : kill -9 <pid>

12. any port you can select ( i have given an example port -2888)
rmiregistry 2888 & 

13. To run the server-
java ohrserver/HotelServer in-csci-rrpc02 <port-number>
for example-
java ohrserver/HotelServer in-csci-rrpc02 2888

 For running the client-

14. # In a different machine: ( To run the client )
(please open another terminal and run command)
ssh username@tesla.cs.uni.edu
15. login to any machine: for example:
ssh old.in-csci-rrpc03.cs.uni.edu

16. cd oodp/OnlineHotelReservation
17. java ohrclient/HotelClient in-csci-rrpc02 <port-number>
for example-
java ohrclient/HotelClient in-csci-rrpc02 2888

NOTE:
   It will give option to register as a customer and login (as admin or as customer). 
 username is "rubaya"
 and correct password is "rabab". 
Role will be shown as admin

 For customer username is "leo" and password is "leo123".
Or username: aj , password: aj123



