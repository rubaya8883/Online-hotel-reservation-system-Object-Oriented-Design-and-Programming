/**
 * 
 */
package ohrcommon;

/**
 * @author Rubaya
 *
 */
public class HotelAdmin {
    public int id;
    public String zone;
    public boolean isPrimary;
    public String cellPhone;
    public HotelAdmin(int id,String Zone,boolean IsPrimary, String cellPhone)
    {
        this.id = id;
        this.zone = Zone;
        this.isPrimary = IsPrimary;
        this.cellPhone = cellPhone;
    }
}
