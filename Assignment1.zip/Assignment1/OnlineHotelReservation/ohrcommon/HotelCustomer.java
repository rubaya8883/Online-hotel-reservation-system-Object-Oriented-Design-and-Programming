/**
 * 
 */
package ohrcommon;

/**
 * @author Rubaya
 *
 */
public class HotelCustomer implements java.io.Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int id;
    public String creditCard;
    public String address;
    public String cellPhone;
    
    public HotelCustomer(int id,String crdtCard,String addr,String cellph)
    {
        this.id = id;
        this.creditCard = crdtCard;
        this.address = addr;
        this.cellPhone = cellph;
    }
}
