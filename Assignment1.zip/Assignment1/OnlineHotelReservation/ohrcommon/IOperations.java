/**
 * 
 */
package ohrcommon;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

/**
 * @author Rubaya
 *
 */
public interface IOperations extends Remote {
	public HotelUser login(String usrname, String pass) throws RemoteException;
    public HotelUser register(String[] data) throws RemoteException;
    public List<HotelRoom> browseHotelRooms(String[] data) throws RemoteException;
    public boolean updateHotelRoom(HotelRoom hr) throws RemoteException;
    public boolean approveHotelReservation(HotelReservation hr) throws RemoteException;
    public List<HotelReservation> getAllReservation(HotelUser hu) throws RemoteException;
    public HotelReservation getReservation(int reservationId) throws RemoteException;
    public boolean placeReservation(HotelReservation hr) throws RemoteException;
    public boolean modifyReservation(HotelReservation hr) throws RemoteException;
    public boolean cancelReservation(HotelReservation hr) throws RemoteException;
    public boolean addAdmin(HotelUser hus,HotelAdmin had ) throws RemoteException;
    public boolean updateAdmin(HotelUser hus,HotelAdmin had ) throws RemoteException;
    public boolean deleteAdmin(HotelUser hus,HotelAdmin had ) throws RemoteException;
    public boolean addCustomer(HotelUser hus,HotelCustomer hcs ) throws RemoteException;
    public boolean updateCustomer(HotelUser hus,HotelCustomer hcs ) throws RemoteException;
    public boolean deleteCustomer(HotelUser us,HotelCustomer cs)throws RemoteException;

}
