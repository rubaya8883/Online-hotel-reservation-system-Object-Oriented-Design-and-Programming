/**
 * 
 */
package ohrcommon;

import java.util.Scanner;

/**
 * @author Rubaya
 *
 */
public class RegisterCustomerView {
	public String[] View()
    {
        String[] customerData = new String[7];
        System.out.print("Enter your name\n");
        
        Scanner scann = new Scanner(System.in);
        customerData[0] = scann.nextLine();
        System.out.print("Enter your username\n");
        customerData[1] = scann.nextLine();
        System.out.print("Enter Password:\n");
        customerData[2] = scann.nextLine();
        customerData[3] = "C";
        System.out.print("Enter Credit card:\n");
        customerData[4] = scann.nextLine();
        System.out.print("Enter Address:\n");
        customerData[5] = scann.nextLine();
        System.out.print("Enter Cellphone:\n");
        customerData[6] = scann.nextLine();
        
        return customerData;
    }
}
