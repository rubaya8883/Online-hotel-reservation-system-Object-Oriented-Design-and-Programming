/**
 * 
 */
package ohrcommon;

import java.util.Scanner;

/**
 * @author Rubaya
 *
 */
public class RoomView {
    public int View()
	{
        String[] roomDescription = {"Room 1, ID: 1", "Room 2, ID: 2", "Room 3, ID: 3\n"};
        System.out.print("Select one of the following room Id\n");
        System.out.print("Room 1, Id: 1 \nRoom 2, Id: 2 \nRoom 3, Id: 3\n");
        Scanner sccan = new Scanner(System.in);
        int id = sccan.nextInt();
        return id;
    }
}
