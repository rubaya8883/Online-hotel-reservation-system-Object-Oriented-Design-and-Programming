/**
 * 
 */
package ohrcommon;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Rubaya
 *
 */
public class HotelUserController implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
    
	public void addUser(HotelUser hus)
    {
        System.out.print("User added successfully! The actual addition to database is yet to be implemented.\n");
    }
    
    public List<HotelUser> getAllUsers() throws FileNotFoundException, IOException
    {
        List<HotelUser> AllUser = new ArrayList<HotelUser>();
        try{
            //String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrUser.csv";
            
        	//String userDbPath = System.getProperty("user.dir") +"\\OnlineHotelReservation"+ "\\ohrcommon"+"\\"+"ohrUser.csv";
        	String userDbPath = System.getProperty("user.dir")+ "/ohrcommon"+"/"+"ohrUser.csv";
            File file = new File(userDbPath);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line = "";
            String[] tempArr;
            int i = 0;
            //List<String> columns = null;
            while((line = br.readLine()) != null) {
               //System.out.print(line+"\n");
               tempArr = line.split(",");
               if (i == 0)
               {
                   i++;
                   continue;
               }
               else{
                   HotelUser hus = new HotelUser(Integer.parseInt(tempArr[0]),tempArr[1],tempArr[2],tempArr[3],tempArr[4]);
                   AllUser.add(hus);
               }
               i++;
           }
        }
         catch(IOException ioe) {
            ioe.printStackTrace();
         }
        return AllUser;
    }
    
    public HotelUser getUserFromLogin(String usrName, String pass)
    {
        HotelUser hus = null;
        List<HotelUser> AllUser = null;
        HotelUserController ctrl =new HotelUserController();
        boolean scheck = false;
        try {
            AllUser = ctrl.getAllUsers();
        } catch (IOException ex) {
            Logger.getLogger(HotelUserController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        for (int i = 0; i< AllUser.size();i++)
        {
            
            //System.out.print(AllUser.get(i).UserName + " " +AllUser.get(i).Password +"\n");
            if ((AllUser.get(i).username.equals(usrName)) && (AllUser.get(i).password.equals(pass)))
            {
                hus = AllUser.get(i);
                scheck = true;
                break;
            }
        }

        return hus;
    }
    
    public HotelUser getUser(int Id)
    {
        HotelUser hus = null;
        List<HotelUser> AllUser = null;
       HotelUserController ctrl =new HotelUserController();
        try {
            AllUser = ctrl.getAllUsers();
        } catch (IOException ex) {
            Logger.getLogger(HotelUserController.class.getName()).log(Level.SEVERE, null, ex);
        }
            //System.out.print(AllUser.size());
        for (int i = 0; i< AllUser.size();i++)
        {
            if (AllUser.get(i).id == Id)
            {
                hus = AllUser.get(i);
            }
        }
        return hus;
    }
    
    

}
