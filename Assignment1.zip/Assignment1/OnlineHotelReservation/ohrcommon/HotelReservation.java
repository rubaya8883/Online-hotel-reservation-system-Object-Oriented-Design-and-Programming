/**
 * 
 */
package ohrcommon;

import java.util.Date;

/**
 * @author Rubaya
 *
 */
public class HotelReservation {
	public int userId;
    public int reservationId;
    public Date fromDate;
    public Date toDate;
    public double chargeAmount;
    public String Status;	
    
    public HotelReservation(int userId, int reservationId, Date fromDate, Date toDate,String Status) 
    {
    		this.userId = userId;
            this.fromDate = fromDate;
            this.toDate = toDate;
            this.Status = Status; 
            this.chargeAmount = 0.0;
                    
}
}
