package ohrcommon;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author Rubaya
 *
 */
public class HotelAdminController implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public void HotelAdmin(HotelAdmin ha)
    {
        System.out.print("Admin added successfully! Not saved in the database yet.\n");
    }
    
    public HotelAdmin getAdmin(int Id)
    {
    	HotelAdmin ha = null;
        List<HotelAdmin> Alladmin = null;
        HotelAdminController ctrl =new HotelAdminController();
        try {
        	Alladmin = ctrl.getAllAdmin();
        } catch (IOException ex) {
            Logger.getLogger(HotelAdminController.class.getName()).log(Level.SEVERE, null, ex);
        }
            //System.out.print(AllCustomer.size());
        for (int i = 0; i< Alladmin.size();i++)
        {
            if (Alladmin.get(i).id == Id)
            {
                ha = Alladmin.get(i);
            }
        }
        return ha;
    }
    
    public List<HotelAdmin> getAllAdmin() throws FileNotFoundException, IOException
    {
        List<HotelAdmin> AllAdmin = new ArrayList<HotelAdmin>();
        try{
            String userDbPath = System.getProperty("user.dir") +"\\src"+ "\\ohrcommon"+"\\"+"ohrAdmin.csv";
        
            File file = new File(userDbPath);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String line = "";
            String[] tempArr;
            int i = 0;

            while((line = br.readLine()) != null) {
               //System.out.print(line+"\n");
               tempArr = line.split(",");
               if (i == 0)
               {
                   i++;
                   continue;
               }
               else{
            	   HotelAdmin us = new HotelAdmin(Integer.parseInt(tempArr[0]),tempArr[1],Boolean.parseBoolean(tempArr[2]),tempArr[3]);
                   AllAdmin.add(us);
               }
               i++;
           }
        }
         catch(IOException ioe) {
            ioe.printStackTrace();
         }
        return AllAdmin;
    }
}
