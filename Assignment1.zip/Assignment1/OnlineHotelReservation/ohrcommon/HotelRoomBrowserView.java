/**
 * 
 */
package ohrcommon;

import java.util.Scanner;

/**
 * @author Rubaya
 *
 */
public class HotelRoomBrowserView {
    public String[] View()
    {
        String[] roomBdata = new String[3];
        System.out.print("Enter From date:\n");
        Scanner obj = new Scanner(System.in);
        roomBdata[0] = obj.nextLine();
        System.out.print("Enter To date:\n");
        roomBdata[1] = obj.nextLine();
        System.out.print("Enter Room Type (suit/single/double):\n");
        roomBdata[2] = obj.nextLine();
        return roomBdata;
    }
}
