/**
 * 
 */
package ohrserver;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 * @author Rubaya
 *
 */
public class HotelServer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			//for the localhost
			/*
		    IOperationImpl serv = new IOperationImpl();
			
			int port = 2403;//Integer.parseInt(args[1]);
            String host = "localhost";//args[0];
                        
			String name="//"+host+":"+port+"/Online_hotel";
			Registry registry = LocateRegistry.createRegistry(port);
			registry.rebind(name, serv);
			*/
			
			
			IOperationImpl serv = new IOperationImpl();
			// Taking the host name of the remote object
			//String host = args[0];
			//int port = Integer.parseInt(args[1]);
			
			//String name="//"+host+":"+port+"/Online_hotel";
			String name = "//in-csci-rrpc01:2888/Online_hotel";
			//Registry registry = LocateRegistry.createRegistry(port);
			//registry.rebind(name, serv);
			Naming.rebind(name,serv);
			
			System.out.println("Server connection established:"+name);
			}
		catch(Exception e) {
			System.out.println("Error while establishing the server" + e.toString());
		}
	}

}
