package ohrclient;

import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.List;
import java.util.Scanner;

import ohrcommon.*;

/**
 * @author Rubaya
 *
 */
public class HotelClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			/*
			//code for the localhost 
			String host = "localhost";//args[0];
			int port = 2403;//Integer.parseInt(args[1]);		
			
			
			String name="//"+host+":"+port+"/Online_hotel";
			Registry registry = LocateRegistry.getRegistry(host,port);
			IOperations op = (IOperations)registry.lookup(name);
			*/
			
			//String host = args[0];
			//int port = Integer.parseInt(args[1]);
			//String name="//"+host+":"+port+"/Online_hotel";
			
			String name= "//in-csci-rrpc01:2888/Online_hotel";
			// Getting the registry 
			//Registry registry = LocateRegistry.getRegistry(host,port);
			
			
			// Looking up the registry for the remote object 
			//IOperations op = (IOperations)registry.lookup(name);
			IOperations op = (IOperations)Naming.lookup(name);

			System.out.println("--------------- Online Hotel Reservation ----------------------- ");
			System.out.println("1.Customer Registration ");
			System.out.println("2.Login");

			System.out.println("---------------------------------------------------------------- ");
			System.out.println("Select an operation: ");
			Scanner scan0 = new Scanner(System.in);
			Integer operation1 = scan0.nextInt();
            
			switch (operation1)
			{
			case 1:
                RegisterCustomerView rcv = new RegisterCustomerView();
                String[] dataForCus = rcv.View();
                HotelUser husForCus = null;
                husForCus = op.register(dataForCus);
                System.out.print("Successfully Registered(NOT SAVED IN DB YET)\n"); 
                break;
			case 2:
                UserLoginView ulv = new UserLoginView();
                String params[] = {"",""};
                params = ulv.View();

                HotelUser hus1 = op.login(params[0],params[1]);
                if (hus1 == null)
                {
                    System.out.print("Login unsuccessful\n");
                }
                else
                {
                    System.out.print("Wellcome " + hus1.name + "\n");
                    if(hus1.role.equals("A"))
                    {
                        System.out.print("Your role is: admin\n");
            			System.out.println("--------------- Admin Activity----------------------- ");

            			System.out.println("1.Add a new Admin ");
            			System.out.println("2.Add Customer Account");
            			System.out.println("3. Remove Customer Account");
            			//System.out.println("4. Exit\n");
            			System.out.println("---------------End Admin Activities----------------------");
            			System.out.println("Select an operation to continue\n");
                        Scanner scan1 = new Scanner(System.in);
                        Integer operationA = scan1.nextInt();
            			switch (operationA)
            			{
            			case 1:
                            RegisterAdminView rav = new RegisterAdminView();
                            String[] dataAdmin = rav.View();
                            HotelUser husa = null;
                            //HotelAdmin ha = null;
                            husa = op.register(dataAdmin);
                            System.out.print("Successfully Registered Admin(NOT SAVED IN DB YET)\n"); 

                            break;
                            
            			case 2:
                            RegisterCustomerView rcva = new RegisterCustomerView();
                            String[] dataForcusA = rcva.View();
                            HotelUser husForcusA = null;
                            husForcusA = op.register(dataForcusA);
                            System.out.print("Successfully Registered the customer by the admin(NOT SAVED IN DB YET)\n"); 
                            break;
            			case 3:  
            				System.out.println("Not implemented yet.");
            				break;
           			    default:
           			    	System.out.println("Invalid input.");
           			    	break;
            			
            			}//switch operationA end
                    }
                    else if(hus1.role.equals("C"))
                    {	
                        System.out.print("Your role is: Customer\n");
                        
            			System.out.println("---------------Customer Activity----------------------- ");
            			System.out.println("1.Browse Rooms ");
            			System.out.println("2.Make a reservation ");
            			System.out.println("3.Modify an existing reservation ");
            			System.out.println("4.Cancel a reservation ");
            			System.out.println("---------------End Customer Activities----------------------");
            			System.out.println("Select an operation to continue\n");
                        //System.out.println("Select an operation to continue\n1. Browse Rooms \n2. Make a reservation \n"
                              //  + "3. Modify an existing reservation"
                               // + "\n4. Cancel a reservation\n");
                        Scanner scan2 = new Scanner(System.in);
                        
                    //}}
                        Integer operation2 = scan2.nextInt();
            			switch (operation2)
            			{
            			case 1:
                            HotelRoomBrowserView hrbv = new HotelRoomBrowserView();
                            String []dataHrbv = hrbv.View();
                            List<HotelRoom> rooms = op.browseHotelRooms(dataHrbv);
                            System.out.print("\nRooms are available for booking!!\n");	
                            break;
            			case 2:
                            RoomView rvw = new RoomView();
                            int id = rvw.View();
                            HotelReservation hr = null;
                            op.placeReservation(hr);
                            System.out.print("\n You have successfully made a reservation!!\n");
                            break;
            			case 3:
                            //HotelReservation hr0 = null;
                        	
                            List<HotelReservation> allresev = op.getAllReservation(hus1);
                            HotelReservationView hrv = new HotelReservationView();
                            int reservationId = hrv.View(allresev);
                            HotelReservation hr1 = op.getReservation(reservationId);
                            op.modifyReservation(hr1);
                            System.out.print("\nReservation is successfully modified!!\n");   
            				break;
            			case 4:
                        	//HotelReservation hr2 = null;
                        	List<HotelReservation> allresev1 = op.getAllReservation(hus1);
                        	HotelReservationView hrv1 = new HotelReservationView();
                            int reservationId1 = hrv1.View(allresev1);
                            HotelReservation hr3 = op.getReservation(reservationId1);
                            op.cancelReservation(hr3);
                            System.out.print("\nReservation is successfully cancelled; You may need to pay\n");
            				break;
            			 default:
                             System.out.println("Invalid input.");
                             break;
                         }// switch operation2
            		}
            	}
                    break;
               default:

                    System.out.println("Invalid input.");

                    break;
			}// switch operation1


		} // try block end
		catch(Exception e){
			System.out.println("Error Occoured: "+e.toString());
		}

	}

}
